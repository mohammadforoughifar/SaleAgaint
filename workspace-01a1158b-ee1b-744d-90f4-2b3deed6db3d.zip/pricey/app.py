"""نقطه‌ی شروعِ نسخه‌ی وب — python app.py  →  http://localhost:8000"""

import asyncio
import json
import os
import sys
import threading
import time
import uuid

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pipeline import run_search          # noqa: E402
from core import contacts                # noqa: E402
from core.watcher import WATCHER         # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(BASE, "web")
SHOPS_JSON = os.path.join(BASE, "data", "shops.json")

app = FastAPI(title="جستجوگر قیمت")
app.add_middleware(                       # برای اینکه در iframe هم کار کند
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

JOBS: dict[str, dict] = {}


@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(WEB, "index.html"), encoding="utf-8") as fh:
        return fh.read()


@app.get("/api/health")
def health():
    return {"ok": True}


# ------------------------------------------------------------------ دیده‌بان قیمت
@app.get("/api/watches")
def watches_list():
    return JSONResponse(WATCHER.snapshot())


@app.get("/api/watches/add")
def watches_add(q: str, target: int = 0, interval: int = 60,
                sources: str = "ترب,دیجی کالا", mode: str = "auto", drop: int = 3):
    if not q.strip():
        return JSONResponse({"error": "عبارت خالی است"}, status_code=400)
    w = WATCHER.add(q, target or None, interval, sources, mode, drop)
    WATCHER.start()
    # همان لحظه یک بار بررسی شود
    WATCHER.run(w["id"])
    return JSONResponse(WATCHER.snapshot())


@app.get("/api/watches/run")
def watches_run(id: str):
    WATCHER.run(id)
    return JSONResponse(WATCHER.snapshot())


@app.get("/api/watches/del")
def watches_del(id: str):
    WATCHER.remove(id)
    return JSONResponse(WATCHER.snapshot())


@app.get("/api/sources")
def api_sources():
    """فهرستِ منابع + وضعیتِ تأیید — که کاربر بداند هر منبع چقدر قابل اعتماد است."""
    from pipeline import SOURCE_META, SOURCES                 # noqa: E402
    return {"sources": [
        {"name": n, "home": SOURCE_META.get(n, {}).get("home", ""),
         "role": SOURCE_META.get(n, {}).get("role", ""),
         "note": SOURCE_META.get(n, {}).get("note", ""),
         "verified": bool(SOURCE_META.get(n, {}).get("verified"))}
        for n in SOURCES
    ]}


@app.get("/api/probe")
def api_probe(source: str = "", q: str = "گوشی سامسونگ"):
    """
    تستِ زنده‌ی یک منبع: روی دستگاهِ خودِ کاربر اجرا می‌شود و نشان می‌دهد
    آن منبع واقعاً چه می‌دهد (چند پیشنهاد + ۵ نمونه). این همان چیزی است که
    اینجا (بدون دسترسی به سایت‌های ایرانی) نمی‌توانستم امتحان کنم.
    """
    from pipeline import SOURCES                              # noqa: E402
    src = (source or "").strip()
    if src not in SOURCES:
        return JSONResponse({"ok": False,
                             "error": f"منبعِ «{src}» وجود ندارد."}, status_code=404)
    t0 = time.time()
    try:
        rows = SOURCES[src].fetch(q, pages=2, timeout=15) or []
    except Exception as e:                                    # noqa: BLE001
        return {"ok": False, "source": src, "query": q,
                "error": f"{type(e).__name__}: {str(e)[:200]}",
                "seconds": round(time.time() - t0, 1)}
    prices = [r.price for r in rows if getattr(r, "price", None)]
    return {
        "ok": True, "source": src, "query": q,
        "count": len(rows), "seconds": round(time.time() - t0, 1),
        "min": min(prices) if prices else None,
        "max": max(prices) if prices else None,
        "samples": [{"title": r.title, "price": r.price, "seller": r.seller,
                     "url": r.url} for r in
                    sorted(rows, key=lambda x: x.price or 0)[:5]],
    }


@app.get("/api/trend")
def api_trend(id: str = "", days: str = "all"):
    """تحلیلِ روندِ یک کالا بر اساسِ تاریخچه‌ای که دیده‌بان جمع کرده است."""
    w = WATCHER.get(id)
    if not w:
        return JSONResponse({"ok": False, "reason": "این کالا دیگر در دیده‌بان نیست."},
                            status_code=404)
    from core.trend import analyze                       # noqa: E402
    out = analyze(w.get("history", []), days)
    out["query"] = w.get("query", "")
    out["id"] = w.get("id", "")
    return out


@app.get("/api/alerts/read")
def alerts_read():
    WATCHER.mark_read()
    return JSONResponse(WATCHER.snapshot())


@app.on_event("startup")
def _boot():                       # noqa: D401
    WATCHER.start()


# ------------------------------------------------------------------ جستجو
@app.get("/api/search")
async def search(
    q: str = Query(..., min_length=1),
    sources: str = "ترب,دیجی کالا",
    mode: str = "auto",
    pages: int = 2,
):
    src = [s.strip() for s in sources.split(",") if s.strip()]
    try:
        data = await asyncio.to_thread(run_search, q, src, mode, max(1, min(pages, 4)))
        # شماره تلفنِ فروشنده‌ها را از دیتابیسِ محلی به هر پیشنهاد اضافه کن
        try:
            table = contacts.phone_table()
            for g in data["result"]["groups"]:
                for o in g["offers"]:
                    o["phone"] = contacts.find_phone(o.get("seller"), table)
        except Exception:
            pass
        return JSONResponse(data)
    except Exception as e:                                # noqa: BLE001
        return JSONResponse({"error": str(e)}, status_code=500)


# ------------------------------------------------------------------ دفترچه تماس
def load_shops():
    try:
        with open(SHOPS_JSON, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {"data_sources": [], "shops": []}


@app.get("/api/shops")
def shops():
    return JSONResponse(load_shops())


@app.get("/api/contacts/start")
def contacts_start(only_missing: int = 1, timeout: int = 10, delay: float = 1.0):
    """خزشِ سایتِ همه‌ی فروشگاه‌ها برای گرفتنِ شماره تماس (در پس‌زمینه)"""
    jid = uuid.uuid4().hex[:8]
    JOBS[jid] = {"id": jid, "done": False, "total": 0, "i": 0, "found": 0,
                 "current": "", "log": [], "rows": [], "error": ""}
    threading.Thread(target=_crawl_job, args=(jid, bool(only_missing), timeout, delay),
                     daemon=True).start()
    return JSONResponse({"job": jid})


@app.get("/api/contacts/status")
def contacts_status(job: str):
    return JSONResponse(JOBS.get(job, {"error": "چنین کاری پیدا نشد"}))


def _rows_of(data):
    rows = []
    for s in data.get("data_sources", []):
        rows.append({"name": s.get("name"), "role": s.get("role", ""),
                     "phone": s.get("phone", "—"), "url": s.get("url", ""),
                     "src": s.get("phone_source", "")})
    for s in data.get("shops", []):
        rows.append({"name": s.get("name"), "role": s.get("category", ""),
                     "phone": s.get("phone", "—"), "url": s.get("url", ""),
                     "src": s.get("phone_source", "")})
    return rows


def _crawl_job(jid, only_missing, timeout, delay):
    job = JOBS[jid]
    try:
        data = load_shops()
        targets = []
        for grp in ("data_sources", "shops"):
            for s in data.get(grp, []):
                if not s.get("url"):
                    continue
                if only_missing and s.get("phone") not in (None, "", "—"):
                    continue
                targets.append(s)
        job["total"] = len(targets)
        job["rows"] = _rows_of(data)

        cache = contacts.load_cache()
        for i, s in enumerate(targets, 1):
            name = s.get("name", "?")
            job["i"], job["current"] = i, name
            try:
                info = contacts.lookup(s["url"], timeout=timeout, cache=cache)
                phones = info.get("phones") or []
                if phones:
                    s["phone"] = " / ".join(phones[:2])
                    s["phone_source"] = "خزش: " + (info.get("source") or "")
                    if info.get("final_url"):
                        s["contact_url"] = info.get("final_url")
                    job["found"] += 1
                    job["log"].append(f"✅ {name}: {s['phone']}")
                elif info.get("reached"):
                    s["phone_source"] = "خزش: شماره‌ای نداشت"
                    job["log"].append(f"⬜ {name}: سایت باز شد ولی شماره‌ای نداشت")
                else:
                    s["phone_source"] = "در دسترس نبود (Timeout/بلاک)"
                    job["log"].append(f"⏱ {name}: پاسخ نداد — احتمالاً IP یا بلاک")
            except Exception as e:                        # noqa: BLE001
                job["log"].append(f"❌ {name}: {type(e).__name__}")
            contacts.save_cache(cache)
            job["rows"] = _rows_of(data)
            if i < len(targets):
                time.sleep(delay)

        with open(SHOPS_JSON, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        try:
            from tools.export_shops import build_rows, write_csv, write_xlsx
            rows = build_rows(data)
            write_csv(rows)
            write_xlsx(rows)
        except Exception:
            pass
        job["rows"] = _rows_of(data)
    except Exception as e:                                # noqa: BLE001
        job["error"] = f"{type(e).__name__}: {e}"
    finally:
        job["done"] = True
        job["current"] = ""


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8000"))
    print(f"\n  آماده!  →  http://localhost:{port}\n")
    uvicorn.run(app, host="0.0.0.0", port=port)
