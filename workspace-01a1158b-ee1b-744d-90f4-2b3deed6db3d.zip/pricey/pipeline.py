"""هماهنگ‌کننده: داده می‌گیرد → تحویل موتور تشخیص می‌دهد → نتیجه می‌سازد"""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutTimeout

from core.matcher import analyze, build_group, strip_internal, Offer, Scored
from collectors import torob, digikala, technolife, demo

SOURCES = {"ترب": torob, "دیجی کالا": digikala, "تکنولایف": technolife}

# وضعیتِ هر منبع — برای اینکه کاربر دقیقاً بداند کدام منبع تست‌شده است
# و کدام نه. اینجا هیچ چیزی را تأیید‌شده فرض نمی‌کنیم مگر اینکه واقعاً
# با واکشیِ زنده امتحانش کرده باشیم.
SOURCE_META = {
    "ترب": {
        "home": "https://torob.com",
        "role": "موتور جستجوی قیمت — خودش چند فروشگاه را جمع می‌کند",
        "verified": False,
        "note": "از خارجِ ایران پاسخ نمی‌دهد؛ برای همین اینجا تستِ زنده نشده. "
                "روی سیستمِ شما باید کار کند.",
    },
    "دیجی کالا": {
        "home": "https://www.digikala.com",
        "role": "فروشگاه بزرگ — هم خودش می‌فروشد هم میزبانِ فروشنده‌هاست",
        "verified": False,
        "note": "از خارجِ Iran در دسترس نبود؛ اینجا تستِ زنده نشده.",
    },
    "تکنولایف": {
        "home": "https://www.technolife.com",
        "role": "فروشگاهِ تک‌فروشنده (خودش می‌فروشد)",
        "verified": True,
        "note": "تست‌شده با واکشیِ واقعی: ۳ مرتب‌سازی همزمان (مرتبط/ارزان/گران) "
                "تا ۶۰ پیشنهادِ یکتا. واحدِ قیمت ریال است (تأیید با JSON-LD: IRR) "
                "و برنامه آن را به تومان تبدیل می‌کند.",
    },
}
_CACHE: dict = {}
CACHE_TTL = 10 * 60          # ۱۰ دقیقه کش


def _friendly(err: Exception) -> str:
    s = str(err).lower()
    if "timed out" in s or "timeout" in s or "connectionerror" in s or "name or service" in s:
        return "عدم دسترسی به اینترنت/سایت (Timeout)"
    if "403" in s:
        return "دسترسی مسدود شد (۴۰۳) — معمولاً به‌خاطر IP یا محدودیتِ API"
    if "429" in s:
        return "تعداد درخواست زیاد (۴۲۹) — کمی صبر کنید"
    if "500" in s or "502" in s or "503" in s:
        return "خطای سمت سرور فروشگاه"
    if "json" in s or "expecting value" in s:
        return "پاسخِ غیرمنتظره از سایت (ساختار عوض شده؟)"
    return f"{type(err).__name__}: {str(err)[:120]}"


# آدرس‌هایی که فقط خودِ صفحه‌ی اصلیِ فروشگاه‌اند — یعنی لینکِ واقعی نداریم
_BARE = {
    "https://torob.com", "https://www.torob.com",
    "https://digikala.com", "https://www.digikala.com",
    "https://technolife.com", "https://www.technolife.com",
}
_SEARCH_URL = {
    "ترب": "https://torob.com/search/?q={q}",
    "دیجی کالا": "https://www.digikala.com/search/?q={q}",
    "تکنولایف": "https://www.technolife.com/product/list/search?keywords={q}",
}


def _fill_urls(offers):
    """
    هیچ ردیفی بدون لینکِ قابل‌استفاده نماند.
    اگر فروشگاه لینکِ محصول را نداد (گاهی ترب/دیجی‌کالا فقط آدرسِ خانه
    می‌دهند)، لینک را به صفحه‌ی جستجوی همان کالا در همان سایت برمی‌گردانیم —
    لینک همیشه واقعی است و جایی می‌رود، فقط به‌جای صفحه‌ی محصول، نتایجِ
    جستجو را نشان می‌دهد.
    """
    from urllib.parse import quote
    for o in offers:
        url = (o.url or "").strip()
        if not url.startswith("http") or url.rstrip("/") in _BARE:
            pat = _SEARCH_URL.get(o.source)
            if pat:
                o.url = pat.format(q=quote((o.title or "").strip()))


def _collect_live(query: str, names: list[str], pages: int, timeout: int):
    offers, ok, errors = [], [], []
    if not names:
        return offers, ok, errors
    with ThreadPoolExecutor(max_workers=max(1, len(names))) as ex:
        futs = {ex.submit(SOURCES[n].fetch, query, pages, timeout): n for n in names}
        try:
            for f in as_completed(futs, timeout=timeout + 15):
                name = futs[f]
                try:
                    res = f.result() or []
                    offers.extend(res)
                    ok.append({"source": name, "count": len(res)})
                except Exception as e:                     # noqa: BLE001
                    errors.append({"source": name, "error": _friendly(e)})
        except FutTimeout:
            for f, name in futs.items():
                if not f.done():
                    errors.append({"source": name, "error": "پاسخ نداد (Timeout)"})
    return offers, ok, errors


# ------------------------------------------------------------------ حالت عمیق
def _deep_key(offer: Offer):
    return (offer.extra or {}).get("prk") or (offer.extra or {}).get("id")


def _deep_one(sc: Scored):
    offer = sc.offer
    key = _deep_key(offer)
    if not key:
        return None
    try:
        if offer.source == "ترب":
            return torob.deep(key)
        if offer.source == "دیجی کالا":
            return digikala.deep(key)
    except Exception:                                     # noqa: BLE001
        return None
    return None


def _deepen(result: dict, timeout: int = 7, max_groups: int = 2, max_products: int = 2) -> int:
    """برای بهترین گروه‌ها می‌رود سراغِ صفحه‌ی محصول و همه‌ی فروشنده‌ها را می‌آورد"""
    q = result.get("_q")
    if not q:
        return 0

    jobs = []
    for gi, g in enumerate(result["groups"][:max_groups]):
        seen, n = set(), 0
        for sc in sorted(g.get("_items") or [], key=lambda x: -x.score):
            k = (sc.offer.source, _deep_key(sc.offer))
            if not k[1] or k in seen:
                continue
            seen.add(k)
            jobs.append((gi, sc))
            n += 1
            if n >= max_products:
                break
    if not jobs:
        return 0

    found: dict[int, list] = {}
    with ThreadPoolExecutor(max_workers=min(4, len(jobs))) as ex:
        futs = {ex.submit(_deep_one, sc): (gi, sc) for gi, sc in jobs}
        try:
            for f in as_completed(futs, timeout=timeout + 6):
                gi, sc = futs[f]
                try:
                    d = f.result()
                except Exception:                          # noqa: BLE001
                    d = None
                if d:
                    found.setdefault(gi, []).append((sc, d))
        except FutTimeout:
            pass

    used = 0
    for gi, lst in found.items():
        g = result["groups"][gi]
        new_items = []
        for sc, d in lst:
            for o in (d.get("offers") or [])[:40]:
                off = Offer(title=sc.offer.title, price=o["price"],
                            seller=o.get("seller") or sc.offer.source,
                            url=sc.offer.url, source=sc.offer.source)
                new_items.append(Scored(offer=off, parsed=sc.parsed, score=sc.score,
                                        acc_ok=sc.acc_ok, group_key=sc.group_key,
                                        group_label=sc.group_label))
        if len(new_items) >= 2:
            g.update(build_group(q, g["_key"], new_items, deep=True))
            used += 1
            continue

        # ترب گاهی فقط خلاصه می‌دهد: کمترین/بیشترینِ واقعیِ بینِ همه‌ی فروشنده‌ها
        sums = [d.get("summary") for _, d in lst if d.get("summary")]
        if sums and sums[0].get("min") and sums[0].get("max"):
            g["min"], g["max"] = sums[0]["min"], sums[0]["max"]
            g["median"] = (g["min"] + g["max"]) // 2
            g["mean"] = g["median"]
            g["deep"] = True
            g["deep_note"] = f"بر اساس {sums[0].get('count') or '؟'} فروشنده در ترب"
            used += 1

    result["groups"].sort(key=lambda x: (-x["exact"], -x["rank"], -x["count"]))
    return used


# ------------------------------------------------------------------ ورودی اصلی
def run_search(query: str, sources: list[str] | None = None, mode: str = "auto",
               pages: int = 2, timeout: int = 10, deep: bool = True) -> dict:
    query = (query or "").strip()
    sources = sources or list(SOURCES.keys())
    started = time.time()

    key = (query, tuple(sources), mode, pages, deep)
    hit = _CACHE.get(key)
    if hit and time.time() - hit["t"] < CACHE_TTL:
        out = dict(hit["data"])
        out["cached"] = True
        return out

    offers, ok, errors, fell_back = [], [], [], False

    if mode == "demo":
        offers = demo.fetch(query)
        ok = [{"source": "داده‌ی نمونه (آفلاین)", "count": len(offers)}]
    else:
        offers, ok, errors = _collect_live(query, sources, pages, timeout)
        _fill_urls(offers)
        if not offers and mode == "auto":
            offers = demo.fetch(query)
            ok = [{"source": "داده‌ی نمونه (آفلاین)", "count": len(offers)}]
            fell_back = True

    result = analyze(query, offers)
    deep_used = 0
    if deep and not (mode == "demo" or fell_back):
        try:
            deep_used = _deepen(result)
        except Exception:                                  # noqa: BLE001
            deep_used = 0

    strip_internal(result)
    data = {
        "result": result,
        "sources_ok": ok,
        "errors": errors,
        "fell_back": fell_back,
        "mode": "demo" if (mode == "demo" or fell_back) else "live",
        "deep_used": deep_used,
        "elapsed": round(time.time() - started, 2),
        "cached": False,
    }
    _CACHE[key] = {"t": time.time(), "data": dict(data)}
    return data
