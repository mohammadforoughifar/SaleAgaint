"""کلکسیونر آفلاین — داده‌ی نمونه را برمی‌گرداند (برای وقتی که سایت‌ها در دسترس نیستند)"""

import json, os
from core.matcher import Offer

PATH = os.path.join(os.path.dirname(__file__), "..", "data", "samples.json")
_CACHE: list[Offer] | None = None


def fetch(query: str = "", **_kw) -> list[Offer]:
    global _CACHE
    if _CACHE is None:
        with open(PATH, encoding="utf-8") as fh:
            rows = json.load(fh)
        _CACHE = [Offer(title=r["title"], price=r["price"], seller=r.get("seller", ""),
                        url=r.get("url", ""), source=r.get("source", ""),
                        image=r.get("image", "")) for r in rows]
    return list(_CACHE)
