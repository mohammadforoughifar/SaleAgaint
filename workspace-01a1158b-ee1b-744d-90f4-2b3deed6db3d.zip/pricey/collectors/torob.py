"""کلکسیونر ترب — جستجو + رفتن به صفحه‌ی محصول برای گرفتنِ همه‌ی فروشنده‌ها"""

import re

import requests

from core.matcher import Offer

API = "https://api.torob.com/v4/base-product/search/"
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "fa-IR,fa;q=0.9,en;q=0.8",
    "Referer": "https://torob.com/",
}

# واحدِ قیمت: "auto" یعنی برنامه خودش با مقایسه‌ی price_text حدس بزند.
# اگر عددها ۱۰ برابر اشتباه بود، این را به "toman" یا "rial" تغییر بده.
PRICE_UNIT = "auto"

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "0123456789" + "0123456789")


def _from_text(s) -> int | None:
    """«۵۲,۰۰۰,۰۰۰ تومان» یا «520,000,000 ریال» را به تومان برمی‌گرداند"""
    if not s:
        return None
    s = str(s)
    t = s.replace("٬", "").replace("٫", "").replace(",", "").replace(" ", "").translate(_DIGITS)
    m = re.findall(r"\d+", t)
    if not m:
        return None
    val = int(m[0])
    if val <= 0:
        return None
    if "ریال" in s or "ريال" in s:
        return val // 10
    if "تومان" in s:
        return val
    return None                       # واحد معلوم نیست


def _calibrate(items: list[dict]) -> int | None:
    """با مقایسه‌ی price_text (که واحدش معلوم است) و price (خام)، ضریب را کشف می‌کند"""
    votes = []
    for it in items[:10]:
        txt = _from_text(it.get("price_text") or it.get("price_str") or "")
        try:
            raw = float(it.get("price"))
        except (TypeError, ValueError):
            continue
        if not txt or raw <= 0:
            continue
        r = raw / txt
        if 8 <= r <= 12:
            votes.append(10)           # price به ریال است
        elif 0.8 <= r <= 1.2:
            votes.append(1)            # price به تومان است
    return max(set(votes), key=votes.count) if votes else None


def _divisor(items: list[dict]) -> int:
    if PRICE_UNIT == "rial":
        return 10
    if PRICE_UNIT == "toman":
        return 1
    return _calibrate(items) or 1      # پیش‌فرض بر اساس شواهد: تومان


def _to_toman(price, div: int = 1):
    if price is None:
        return None
    try:
        price = float(price)
    except (TypeError, ValueError):
        return None
    if price <= 0:
        return None
    return int(price / div)


def _price_of(item, div: int):
    return _from_text(item.get("price_text") or item.get("price_str") or "") or _to_toman(item.get("price"), div)


# چند مدل پارامتر مختلف — اگر یکی خالی برگشت، بعدی را امتحان می‌کنیم
PARAM_SETS = [
    {"page": 0, "size": 24, "sort": "popularity", "source": "next_desktop"},
    {"page": 0, "size": 24},
    {"page": 0},
    {},
]


def fetch(query: str, pages: int = 2, timeout: int = 10) -> list[Offer]:
    """جستجو در ترب — نتایجِ صفحه‌ی لیست"""
    session = requests.Session()
    session.headers.update(HEADERS)

    data, last_err = None, None
    for n, base in enumerate(PARAM_SETS, start=1):
        params = dict(base)
        params["q"] = query
        params["query"] = query
        try:
            # تلاشِ اول با زمانِ کامل، تلاش‌های بعدی کوتاه‌تر
            t = timeout if n == 1 else max(4, timeout // 2)
            r = session.get(API, params=params, timeout=t)
            r.raise_for_status()
            d = r.json()
        except Exception as e:                     # noqa: BLE001
            last_err = e
            # خطای شبکه (تایم‌اوت/بلاک) با پارامترِ دیگر درست نمی‌شود → ادامه نده
            if n >= 2:
                break
            continue
        if d.get("results"):
            data = d
            break
        data = data or d
    if data is None:
        if last_err:
            raise last_err
        return []

    raw: list[dict] = list(data.get("results") or [])
    next_url = data.get("next")
    for _ in range(1, pages):
        if not next_url:
            break
        try:
            r = session.get(next_url, timeout=timeout)
            r.raise_for_status()
            d = r.json()
        except Exception:                          # noqa: BLE001
            break
        raw.extend(d.get("results") or [])
        next_url = d.get("next")

    div = _divisor(raw)
    offers = []
    for it in raw:
        offers.append(Offer(
            title=(it.get("name1") or it.get("name2") or "").strip(),
            price=_price_of(it, div),
            seller=(it.get("shop_name") or it.get("shop_text") or "").strip(),
            url="https://torob.com" + (it.get("web_client_absolute_url") or ""),
            source="ترب",
            image=it.get("image_url") or "",
            extra={"prk": it.get("prk") or it.get("random_key") or it.get("id"),
                   "div": div},
        ))
    return offers


DEEP_URLS = [
    "https://api.torob.com/v4/product-page/",
    "https://api.torob.com/v4/base-product/details/",
]


def deep(prk, timeout: int = 8) -> dict | None:
    """صفحه‌ی محصولِ ترب: همه‌ی فروشنده‌ها (کمترین/بیشترین واقعی)"""
    for url in DEEP_URLS:
        try:
            r = requests.get(url, params={"prk": prk}, headers=HEADERS, timeout=timeout)
            if r.status_code != 200:
                continue
            data = r.json()
        except Exception:
            continue

        name = data.get("productName") or data.get("name1") or ""
        raw = data.get("sellers") or data.get("results") or []
        div = _divisor(raw)
        offers = []
        for it in raw:
            p = _price_of(it, div)
            if not p:
                continue
            offers.append({
                "price": p,
                "seller": (it.get("shop_name") or it.get("name")
                           or it.get("seller_name") or "").strip(),
            })
        if offers:
            return {"title": name, "offers": offers}

        # فقط خلاصه: کمترین/بیشترینِ خودِ ترب (این دو فیلد قطعاً به ریال‌اند)
        lo, hi = data.get("lowPriceRial"), data.get("highPriceRial")

        def tm(v):
            try:
                return int(float(v) / 10) if v else None
            except (TypeError, ValueError):
                return None

        if lo or hi:
            return {"title": name, "offers": [],
                    "summary": {"min": tm(lo), "max": tm(hi), "count": data.get("offerCount")}}
    return None
