"""
کلکسیونر تکنولایف (technolife.com)
-----------------------------------
منبع: صفحه‌ی جستجوی سایت که داده‌اش را به‌صورتِ SSR درونِ
      <script id="__NEXT_DATA__"> می‌گذارد.

مسیرِ داده (که با واکشیِ واقعی در ۲۰۲۶-۱۰ تأیید شده):

    props.pageProps.dehydratedState.queries[]
      → آن‌که queryKey[0] == "search"
      → state.data.pages[*].results[]

فیلدهای هر نتیجه:
    name               عنوانِ کاملِ فارسی
    normal_price       قیمتِ مبنا
    discounted_price   قیمتِ پس از تخفیف (اگر بود)
    code               مثل «TLP-390330»  ← با این لینکِ محصول ساخته می‌شود
    available          ۱ یعنی موجود
    image              مسیرِ نسبیِ تصویر

واحدِ قیمت — نکته‌ی مهم:
    عددها **ریال** هستند (تأییدشده با JSON-LD ی صفحه‌ی محصول:
    "priceCurrency": "IRR"). خودِ سایت در رابط عددِ ریال را با برچسبِ
    «تومان» نشان می‌دهد که اشتباه است — برای همین اینجا بر ۱۰ تقسیم
    می‌کنیم تا مثل بقیه‌ی منابع به تومان برسد.
"""

import json
import re

import requests

from core.matcher import Offer

BASE = "https://www.technolife.com"
SEARCH = BASE + "/product/list/search?keywords={q}"
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "fa-IR,fa;q=0.9,en;q=0.8",
}
RIAL_TO_TOMAN = 10          # عددهای سایت ریال است؛ ما به تومان می‌بریم
MAX_RESULTS = 60            # هر صفحه ۳۰ تا می‌دهد؛ دو صفحه کافی است


def _next_data(html: str):
    m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None


def _find_results(data):
    """resultهای جستجو را از هر کجای درختِ Next.js پیدا می‌کند."""
    if not isinstance(data, dict):
        return None
    queries = (data.get("props", {}).get("pageProps", {})
                   .get("dehydratedState", {}).get("queries"))
    if isinstance(queries, list):
        for q in queries:
            qk = q.get("queryKey")
            if isinstance(qk, list) and qk and qk[0] == "search":
                pages = (q.get("state", {}).get("data") or {}).get("pages") or []
                out = []
                for p in pages:
                    if isinstance(p, dict) and isinstance(p.get("results"), list):
                        out.extend(p["results"])
                if out:
                    return out
    return None


def _product_url(code: str) -> str:
    """«TLP-390330» → https://www.technolife.com/product-390330/"""
    if not code:
        return BASE
    num = re.sub(r"\D", "", str(code))
    return f"{BASE}/product-{num}/" if num else BASE


def _to_toman(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return None
    return v // RIAL_TO_TOMAN if v > 0 else None


def _fetch_one(query: str, ordering: str | None, timeout: int) -> list[dict]:
    """یک واکشی — ordering: None (مرتبط‌ترین) | price-asc | price-desc"""
    url = SEARCH.format(q=requests.utils.quote(str(query or "")))
    if ordering:
        url += "&ordering=" + ordering
    r = requests.get(url, headers=HEADERS, timeout=timeout)
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}")
    data = _next_data(r.text)
    return _find_results(data) if data else None


def fetch(query: str, pages: int = 2, timeout: int = 15) -> list[Offer]:
    """
    جستجو در تکنولایف — برمی‌گرداند لیستی از Offer (قیمت به تومان).

    چرا سه تا واکشی؟ سایت در هر بار فقط ۳۰ نتیجه می‌دهد. برای اینکه
    کمترین و بیشترینِ واقعی را از دست ندهیم، همزمان سه مرتب‌سازی را
    می‌گیریم و با هم ادغام می‌کنیم:
        · مرتبط‌ترین   → بهترین چیزی که موتورِ تشخیصِ مدل نیاز دارد
        · ارزان‌ترین   → کفِ قیمت
        · گران‌ترین    → سقفِ قیمت
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    raw, errors = [], []
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs = {ex.submit(_fetch_one, query, o, timeout): (o or "مرتبط")
                for o in (None, "price-asc", "price-desc")}
        for f in as_completed(futs):
            try:
                rows = f.result()
                if rows:
                    raw.extend(rows)
            except Exception as e:                          # noqa: BLE001
                errors.append(f"{futs[f]}: {type(e).__name__}")

    if not raw:
        raise RuntimeError(" ; ".join(errors) if errors
                           else "نتیجه‌ای برای این عبارت پیدا نشد")

    seen, results = set(), []
    for it in raw:
        key = it.get("code") or it.get("_id") or (it.get("name") or "")
        if key and key in seen:
            continue
        seen.add(key)
        results.append(it)

    offers = []
    for it in results[:MAX_RESULTS]:
        name = (it.get("name") or "").strip()
        if not name:
            continue
        price = _to_toman(it.get("discounted_price") or it.get("normal_price"))
        if not price:
            continue
        offers.append(Offer(
            title=name,
            price=price,
            seller="تکنولایف",
            url=_product_url(it.get("code", "")),
            source="تکنولایف",
            image=(BASE + it["image"]) if it.get("image", "").startswith("/") else it.get("image", ""),
            extra={"code": it.get("code", ""),
                   "available": it.get("available"),
                   "normal_price": _to_toman(it.get("normal_price")),
                   "discount": it.get("discount") or ""},
        ))
    return offers
