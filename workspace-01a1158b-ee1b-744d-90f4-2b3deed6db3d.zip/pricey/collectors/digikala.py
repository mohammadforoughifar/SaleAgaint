"""کلکسیونر دیجی‌کالا — جستجو + صفحه‌ی محصول"""

import requests

from core.matcher import Offer

API = "https://api.digikala.com/v1/search/"
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "fa-IR,fa;q=0.9,en;q=0.8",
    "Referer": "https://www.digikala.com/",
}

# قیمت‌های دیجی‌کالا در این API به ریال هستند
PRICE_UNIT = "rial"


def _to_toman(price):
    if price is None:
        return None
    try:
        price = float(price)
    except (TypeError, ValueError):
        return None
    if price <= 0:
        return None
    return int(price / 10) if PRICE_UNIT == "rial" else int(price)


def _selling(node: dict):
    if not isinstance(node, dict):
        return None
    return _to_toman(node.get("selling_price") or node.get("price"))


def fetch(query: str, pages: int = 2, timeout: int = 10) -> list[Offer]:
    out: list[Offer] = []
    session = requests.Session()
    session.headers.update(HEADERS)

    for page in range(1, pages + 1):
        r = session.get(API, params={"q": query, "page": page}, timeout=timeout)
        r.raise_for_status()
        data = r.json()
        products = (data.get("data") or {}).get("products") or []
        if not products:
            break
        for p in products:
            title = p.get("title_fa") or p.get("title_en") or ""
            variant = p.get("default_variant") or {}
            price = _selling(variant.get("price") or {}) or _selling(p.get("price") or {})
            url = p.get("url") or {}
            uri = url.get("uri") if isinstance(url, dict) else None
            out.append(Offer(
                title=title.strip(),
                price=price,
                seller=(p.get("seller") or {}).get("title") or "",
                url="https://www.digikala.com" + (uri or ""),
                source="دیجی کالا",
                image=(p.get("images") or {}).get("main", {}).get("url", "") or "",
                extra={"id": p.get("id")},
            ))
        pager = (data.get("data") or {}).get("pager") or {}
        try:
            if page >= int(pager.get("total_pages") or 1):
                break
        except (TypeError, ValueError):
            break
    return out


def deep(product_id, timeout: int = 8) -> dict | None:
    """صفحه‌ی محصولِ دیجی‌کالا — قیمتِ فروشنده‌های مختلف"""
    for ver in (2, 1):
        try:
            r = requests.get(f"https://api.digikala.com/v{ver}/product/{product_id}/",
                             headers=HEADERS, timeout=timeout)
            if r.status_code != 200:
                continue
            data = r.json()
        except Exception:
            continue

        prod = (data.get("data") or {}).get("product") or data.get("product") or {}
        if not prod:
            continue
        title = prod.get("title_fa") or ""

        offers = []
        for s in (prod.get("sellers") or []):
            p = _selling(s.get("price") or {}) or _to_toman(s.get("selling_price"))
            if not p:
                continue
            offers.append({"price": p, "seller": (s.get("title") or s.get("name") or "").strip()})

        if not offers:
            dv = prod.get("default_variant") or {}
            p = _selling(dv.get("price") or {}) or _selling(prod.get("price") or {})
            if p:
                offers.append({"price": p,
                               "seller": (prod.get("seller") or {}).get("title") or ""})
        if offers:
            return {"title": title, "offers": offers}
    return None
