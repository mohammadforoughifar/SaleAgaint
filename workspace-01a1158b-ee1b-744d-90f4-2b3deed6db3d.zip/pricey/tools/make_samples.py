"""سازنده‌ی داده‌ی نمونه — برای تستِ موتور تشخیص بدون نیاز به اینترنت"""

import json, os, random
from urllib.parse import quote

random.seed(1403)

SELLERS = ["دیجی کالا", "تکنولایف", "موبایل ۷۲۴", "آریا استور", "کالا مارکت", "شاپ نت",
           "ایران استور", "پارس موبایل", "لپ تاپ سنتر", "شهر کالا", "فروشگاه آفتاب",
           "تاپ شاپ", "موبایل لند", "سیتی کالا", "بانه مارکت", "آی تی شاپ"]
SOURCES = ["ترب", "دیجی کالا"]


def link(source, title):
    """در حالت نمونه، لینک به «صفحه‌ی جستجوی واقعیِ همان سایت» می‌رود
       (نه یک آدرس ساختگیِ example.com)"""
    q = quote(title)
    if source == "ترب":
        return "https://torob.com/search/?q=" + q
    return "https://www.digikala.com/search/?q=" + q


def fam(titles, cap, base, n, spread=0.10):
    return dict(titles=titles, cap=cap, base=base, n=n, spread=spread)


FAMILIES = [
    # ---------------- سامسونگ S24 Ultra ----------------
    fam([
        "گوشی موبایل سامسونگ مدل Galaxy S24 Ultra SM-S928B/DS دو سیم کارت ظرفیت 256 گیگابایت و رم 12 گیگابایت - ویتنام",
        "موبایل سامسونگ Galaxy S24 Ultra 256GB دو سیم کارت",
        "گوشی سامسونگ گلکسی اس 24 اولترا 256 گیگ - رنگ مشکی",
        "گوشی سامسونگ گلکشی اس24 اولترا 256",             # غلط املایی عمدی
        "Samsung Galaxy S24 Ultra 256GB 12GB RAM Dual SIM Titanium Black",
        "گوشی موبایل سامسونگ S24 Ultra ظرفیت 256 گیگابایت",
        "سامسونگ گلکسی اس 24 اولترا 256 گیگابایت",
    ], 256, 52_000_000, 18),

    fam([
        "گوشی موبایل سامسونگ مدل Galaxy S24 Ultra دو سیم کارت ظرفیت 512 گیگابایت و رم 12 گیگابایت",
        "موبایل سامسونگ Galaxy S24 Ultra 512GB",
        "گوشی سامسونگ اس24 اولترا 512 گیگ تیتانیوم بنفش",
        "Samsung S24 Ultra 512GB Dual SIM",
    ], 512, 59_500_000, 11),

    fam([
        "گوشی موبایل سامسونگ Galaxy S24 Ultra ظرفیت 1 ترابایت رم 12 گیگابایت",
        "موبایل سامسونگ S24 Ultra 1TB",
    ], 1024, 68_000_000, 5),

    fam([
        "گوشی موبایل سامسونگ مدل Galaxy S24 Plus ظرفیت 256 گیگابایت",
        "سامسونگ گلکسی اس 24 پلاس 256 گیگ",
        "Samsung Galaxy S24 Plus 256GB",
    ], 256, 41_000_000, 7),

    # ---------------- آیفون ----------------
    fam([
        "گوشی موبایل اپل مدل iPhone 15 Pro Max دو سیم کارت ظرفیت 256 گیگابایت",
        "آیفون 15 پرو مکس 256 گیگابایت - تیتانیوم طبیعی",
        "Apple iPhone 15 Pro Max 256GB",
        "گوشی اپل آیفون 15 پرو مکس ظرفیت 256",
    ], 256, 118_000_000, 14),

    fam([
        "گوشی موبایل اپل مدل iPhone 15 Pro Max ظرفیت 512 گیگابایت",
        "آیفون 15 پرو مکس 512 گیگ",
    ], 512, 136_000_000, 8),

    fam([
        "گوشی موبایل اپل مدل iPhone 15 ظرفیت 128 گیگابایت",
        "آیفون 15 معمولی 128 گیگ",
    ], 128, 79_000_000, 6),

    # ---------------- شیائومی ----------------
    fam([
        "گوشی موبایل شیائومی مدل Redmi Note 13 Pro دو سیم کارت ظرفیت 256 گیگابایت و رم 8 گیگابایت",
        "شیائومی ردمی نوت 13 پرو 256 گیگ",
        "Xiaomi Redmi Note 13 Pro 256GB 8GB RAM",
        "گوشی شیائومی نوت 13 پرو 256",
    ], 256, 13_500_000, 13),

    fam([
        "گوشی موبایل شیائومی مدل Redmi Note 13 Pro ظرفیت 512 گیگابایت",
        "شیائومی ردمی نوت 13 پرو 512 گیگ",
    ], 512, 16_200_000, 7),

    # ---------------- لپ تاپ ----------------
    fam([
        "لپ تاپ ایسوس مدل Vivobook 15 X1504ZA پردازنده Core i7 1255U رم 16 گیگابایت حافظه 512 گیگابایت SSD",
        "لپ تاپ 15 اینچی ایسوس Vivobook 15 i7 16GB 512SSD",
        "Asus Vivobook 15 Core i7 16GB RAM 512GB SSD",
    ], 512, 41_000_000, 9),

    fam([
        "لپ تاپ ایسوس مدل Vivobook 15 X1502ZA پردازنده Core i5 1235U رم 8 گیگابایت حافظه 256 گیگابایت SSD",
        "Asus Vivobook 15 i5 8GB 256GB SSD",
    ], 256, 28_500_000, 7),

    # ---------------- کنسول ----------------
    fam([
        "کنسول بازی سونی مدل PlayStation 5 ظرفیت 1 ترابایت - رده بندی دیسک خور",
        "پلی استیشن 5 دیسک خور 1 ترابایت",
        "Sony PlayStation 5 Disc Edition 1TB",
    ], 1024, 31_000_000, 6),

    fam([
        "کنسول بازی سونی مدل PlayStation 5 Digital Edition ظرفیت 1 ترابایت",
        "پلی استیشن 5 دیجیتال 1 ترابایت",
    ], 1024, 26_000_000, 5),
]

# ---------------- لوازم جانبی (باید حذف شوند) ----------------
ACCESSORIES = [
    ("قاب سیلیکونی مات مخصوص گوشی سامسونگ Galaxy S24 Ultra", 89_000),
    ("گلس سرامیکی محافظ صفحه نمایش سامسونگ S24 Ultra", 145_000),
    ("شارژر دیواری سامسونگ 45 وات Super Fast Charging", 690_000),
    ("کابل تبدیل Type-C به Type-C سامسونگ 1.5 متر", 120_000),
    ("قاب چرمی کلاسوری برای گوشی آیفون 15 پرو مکس", 320_000),
    ("محافظ لنز دوربین سامسونگ اس 24 اولترا", 75_000),
    ("پاوربانک انکر 20000 میلی آمپر", 1_250_000),
    ("پایه نگهدارنده موبایل روی میز", 210_000),
]

# ---------------- کالاهای کاملاً نامرتبط (باید حذف شوند) ----------------
UNRELATED = [
    ("جاروبرقی فیلیپس مدل FC9350 توان 2000 وات", 9_800_000),
    ("ماشین لباسشویی بوش 8 کیلویی مدل WAW32560", 42_000_000),
    ("ساعت هوشمند شیائومی مدل Mi Band 8", 1_450_000),
    ("تلویزیون ال ای دی سامسونگ 55 اینچ مدل TU8000", 32_000_000),
    ("هدفون بلوتوثی انکر مدل Soundcore Life Q30", 3_200_000),
]


def make():
    rows = []
    for f in FAMILIES:
        for i in range(f["n"]):
            title = random.choice(f["titles"])
            price = int(f["base"] * (1 + random.uniform(-f["spread"], f["spread"] * 1.3)))
            price = round(price / 10_000) * 10_000
            srcsel = random.choice(SOURCES)
            rows.append({
                "title": title,
                "price": price,
                "seller": random.choice(SELLERS),
                "url": link(srcsel, title),
                "source": srcsel,
                "image": "",
            })
    for t, p in ACCESSORIES + UNRELATED:
        for _ in range(random.randint(1, 3)):
            price = round(p * (1 + random.uniform(-0.15, 0.25)) / 1000) * 1000
            srcsel = random.choice(SOURCES)
            rows.append({
                "title": t, "price": price,
                "seller": random.choice(SELLERS),
                "url": link(srcsel, t),
                "source": srcsel, "image": "",
            })

    # چند قیمت دیوانه برای تست حذفِ نویز
    rows.append({"title": "گوشی موبایل سامسونگ مدل Galaxy S24 Ultra ظرفیت 256 گیگابایت",
                 "price": 1_000_000, "seller": "فروشنده نامعتبر",
                 "url": link("ترب", "Galaxy S24 Ultra 256"), "source": "ترب", "image": ""})
    rows.append({"title": "گوشی سامسونگ اس 24 اولترا 256 گیگ",
                 "price": 480_000_000, "seller": "فروشنده نامعتبر",
                 "url": link("ترب", "Galaxy S24 Ultra 256"), "source": "ترب", "image": ""})
    # بدون قیمت
    rows.append({"title": "گوشی موبایل سامسونگ Galaxy S24 Ultra 256 گیگابایت", "price": None,
                 "seller": "ناموجود",
                 "url": link("دیجی کالا", "Galaxy S24 Ultra 256"),
                 "source": "دیجی کالا", "image": ""})

    random.shuffle(rows)
    return rows


if __name__ == "__main__":
    path = os.path.join(os.path.dirname(__file__), "..", "data", "samples.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rows = make()
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=1)
    print("ساخته شد:", os.path.abspath(path), "| تعداد:", len(rows))
