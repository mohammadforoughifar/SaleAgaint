#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
استخراجِ فروشنده‌های یک کالا — هر فروشنده یک سطر
--------------------------------------------------
اجرا روی سیستم خودت (با اینترنتِ ایران):

    python tools/sellers.py "سامسونگ اس24 اولترا 256"

خروجی:
  • جدول در صفحه
  • data/sellers.csv
  • data/sellers.xlsx

ستون‌ها: ردیف | کالا | فروشنده | شماره تماس | قیمت (تومان) | منبع | لینک
"""

import argparse
import csv
import json
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SHOPS_JSON = os.path.join(BASE, "data", "shops.json")
CSV_OUT = os.path.join(BASE, "data", "sellers.csv")
XLSX_OUT = os.path.join(BASE, "data", "sellers.xlsx")
CONTACTS_OUT = os.path.join(BASE, "data", "seller_contacts.csv")
HEADERS = ["ردیف", "کالا", "فروشنده", "شماره تماس", "قیمت (تومان)", "منبع", "لینک"]


def norm(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"[\s\-_()«»\.,،:/\\]+", "", s)
    s = s.replace("ك", "ک").replace("ي", "ی").replace("ة", "ه")
    s = s.replace("آ", "ا").replace("أ", "ا").replace("إ", "ا")
    return s


def load_phones() -> dict:
    try:
        with open(SHOPS_JSON, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return {}
    table = {}
    for s in data.get("shops", []) + data.get("data_sources", []):
        name = s.get("name")
        if name:
            table[norm(name)] = s.get("phone") or "—"
    return table


def find_phone(seller: str, table: dict) -> str:
    n = norm(seller)
    if not n:
        return "—"
    if n in table:
        return table[n]
    for k, v in table.items():          # تطبیقِ جزئی: «تکنولایف | فروشگاه آنلاین»
        if len(k) >= 4 and (k in n or (len(n) >= 4 and n in k)):
            return v
    return "—"


def collect(query: str, mode: str = "auto", groups_n: int = 2):
    from pipeline import run_search
    res = run_search(query, mode=mode, deep=True)
    out = []
    for g in res["result"]["groups"][:groups_n]:
        for o in g["offers"]:
            out.append({
                "product": g["label"],
                "seller": o.get("seller") or o.get("source") or "",
                "price": o.get("price"),
                "source": o.get("source", ""),
                "url": o.get("url", ""),
            })
    return out, res


def write_csv(rows):
    with open(CSV_OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(HEADERS)
        for i, r in enumerate(rows, 1):
            w.writerow([i, r["product"], r["seller"], r.get("phone", "—"),
                        r["price"], r["source"], r["url"]])
    print("  ✓", CSV_OUT)


def write_xlsx(rows):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill
    except ImportError:
        print("  (اکسل ساخته نشد: pip install openpyxl)")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = "فروشنده‌ها"
    ws.sheet_view.rightToLeft = True
    ws.append(HEADERS)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="2E7D32")
        c.alignment = Alignment(horizontal="center")
    for i, r in enumerate(rows, 1):
        ws.append([i, r["product"], r["seller"], r.get("phone", "—"),
                   r["price"], r["source"], r["url"]])
    for col, w in zip("ABCDEFG", [6, 26, 24, 22, 18, 12, 46]):
        ws.column_dimensions[col].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(horizontal="right")
    ws.freeze_panes = "A2"
    wb.save(XLSX_OUT)
    print("  ✓", XLSX_OUT)


def enrich_contacts(rows, timeout=10, only_missing=True, verbose=True):
    """با دنبال‌کردنِ لینکِ هر فروشنده، شماره تلفن را از سایتِ خودش می‌گیرد"""
    from core import contacts
    cache = contacts.load_cache()
    seen: dict[str, dict] = {}
    total = len(rows)
    for i, r in enumerate(rows, 1):
        if only_missing and r.get("phone", "—") not in ("—", "", None):
            continue
        url = r.get("url") or ""
        if not url:
            continue
        if verbose:
            print(f"   ... {i}/{total} جستجوی تماس برای «{r['seller']}»", flush=True)
        info = contacts.lookup(url, timeout=timeout, cache=cache)
        r["site"] = info.get("site", "")
        r["contact_source"] = info.get("source", "")
        if info.get("phones"):
            r["phone"] = " / ".join(info["phones"][:2])
        seen.setdefault(info.get("site") or url, {
            "site": info.get("site", ""), "phones": info.get("phones", []),
            "url": info.get("final_url", ""), "source": info.get("source", ""),
        })
    contacts.save_cache(cache)

    # جدولِ دوم: فروشگاه‌هایی که پیدا شدند
    with open(CONTACTS_OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["دامنه", "شماره تلفن", "صفحه‌ی منبع", "لینک"])
        for v in seen.values():
            w.writerow([v["site"], " / ".join(v["phones"]) or "—",
                        v["source"], v["url"]])
    if seen:
        print("  ✓", CONTACTS_OUT)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="?", default="گوشی سامسونگ اس24 اولترا 256")
    ap.add_argument("--mode", default="auto", choices=["auto", "demo", "live"])
    ap.add_argument("--groups", type=int, default=2)
    ap.add_argument("--contacts", action="store_true",
                    help="دنبال‌کردنِ لینکِ فروشنده‌ها و استخراجِ شماره تماس از سایتِ خودشان")
    ap.add_argument("--timeout", type=int, default=10)
    args = ap.parse_args()

    print("=" * 70)
    print("  استخراجِ فروشنده‌ها —", args.query)
    print("=" * 70)

    rows, res = collect(args.query, args.mode, args.groups)
    if not rows:
        print("\n  هیچ فروشنده‌ای پیدا نشد.")
        print("  منابع:", res.get("sources_ok"))
        print("  خطاها:", res.get("errors"))
        return 1

    phones = load_phones()
    for r in rows:
        r["phone"] = find_phone(r["seller"], phones)

    if args.contacts:
        print(f"\n  🔎 دنبال کردنِ لینکِ {len(rows)} فروشنده (ممکن است کمی طول بکشد)...")
        rows = enrich_contacts(rows, timeout=args.timeout)

    print(f"\n  {len(rows)} فروشنده پیدا شد:\n")
    print(f"  {'#':>3}  {'فروشنده':<26} {'شماره تماس':<22} {'قیمت':>14}  منبع")
    print("  " + "-" * 84)
    for i, r in enumerate(rows, 1):
        price = f"{r['price']:,}" if r["price"] else "—"
        print(f"  {i:>3}  {r['seller'][:26]:<26} {r['phone'][:22]:<22} {price:>14}  {r['source']}")

    write_csv(rows)
    write_xlsx(rows)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
