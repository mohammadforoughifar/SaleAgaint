#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
پُر کردنِ شماره تلفنِ فروشگاه‌ها با خزشِ سایتِ خودشان
------------------------------------------------------
    python tools/contacts_all.py

• همه‌ی فروشگاه‌های data/shops.json را می‌گردد
• برای هر کدام: سایت را باز می‌کند → صفحه‌ی «تماس با ما» → شماره تلفن
• نتیجه را در shops.json ذخیره می‌کند و جدول را دوباره می‌سازد

گزینه‌ها:
  --all         همه را دوباره بگرد (حتی آن‌هایی که شماره دارند)
  --timeout N   فرصتِ هر درخواست (پیش‌فرض ۱۰ ثانیه)
  --limit N     فقط N فروشگاهِ اول (برای تست)
  --delay S     مکث بین درخواست‌ها (پیش‌فرض ۱ ثانیه)
"""

import argparse
import json
import os
import shutil
import sys
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from core import contacts            # noqa: E402

SHOPS_JSON = os.path.join(BASE, "data", "shops.json")
BACKUP = os.path.join(BASE, "data", "shops.json.bak")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--timeout", type=int, default=10)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--delay", type=float, default=1.0)
    args = ap.parse_args()

    with open(SHOPS_JSON, encoding="utf-8") as fh:
        data = json.load(fh)

    shutil.copyfile(SHOPS_JSON, BACKUP)     # پشتیبان
    print("  پشتیبان:", os.path.basename(BACKUP))

    targets = []
    for grp in ("data_sources", "shops"):
        for s in data.get(grp, []):
            if not s.get("url"):
                continue
            missing = (s.get("phone") in (None, "", "—"))
            if args.all or missing:
                targets.append((grp, s))
    if args.limit:
        targets = targets[:args.limit]

    print(f"\n  {len(targets)} سایت باید بررسی شود\n")
    print(f"  {'#':>3}  {'نام':<20} {'شماره':<24} منبع")
    print("  " + "-" * 76)

    cache = contacts.load_cache()
    found_n = 0
    for i, (grp, s) in enumerate(targets, 1):
        name = s.get("name", "?")
        try:
            info = contacts.lookup(s["url"], timeout=args.timeout, cache=cache)
            phones = info.get("phones") or []
            site = info.get("site") or ""
            src = info.get("source") or ""
        except Exception as e:                                  # noqa: BLE001
            phones, site, src = [], "", f"خطا: {type(e).__name__}"

        if phones:
            s["phone"] = " / ".join(phones[:2])
            s["phone_source"] = f"خزش: {src}"
            if info.get("final_url"):
                s["contact_url"] = info["final_url"]
            found_n += 1
        elif site and site not in ("", name):
            s["phone_source"] = "خزش: شماره‌ای پیدا نشد"

        shown = s.get("phone", "—")
        if len(shown) > 24:
            shown = shown[:21] + "..."
        print(f"  {i:>3}  {name[:20]:<20} {shown:<24} {src}")
        sys.stdout.flush()

        contacts.save_cache(cache)
        if i < len(targets):
            time.sleep(args.delay)

    with open(SHOPS_JSON, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)

    print(f"\n  ✅ شماره‌ی {found_n} فروشگاه پیدا و ذخیره شد")

    # جدول را دوباره بساز
    try:
        from tools.export_shops import build_rows, write_csv, write_xlsx
        rows = build_rows(data)
        print()
        write_csv(rows)
        write_xlsx(rows)
    except Exception as e:                                      # noqa: BLE001
        print("  (ساخت جدول ناموفق بود:", e, ")")

    print("\n  خلاصه:")
    for grp in ("data_sources", "shops"):
        for s in data.get(grp, []):
            mark = "✅" if s.get("phone") not in (None, "", "—") else "—"
            print(f"   {mark} {s.get('name',''):<20} {s.get('phone','—')}")


if __name__ == "__main__":
    main()
