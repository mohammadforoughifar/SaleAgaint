#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ابزار تشخیص — ارتباط واقعی با ترب و دیجی‌کالا را تست می‌کند
------------------------------------------------------------
اجرا:   python tools/diagnose.py "گوشی سامسونگ اس24 اولترا"
خروجی:  هم در صفحه چاپ می‌شود هم در فایل diagnose_report.txt ذخیره می‌گردد
        (آن فایل را برای من بفرست تا کلکسیونرها را دقیق تنظیم کنم)
"""

import json
import os
import sys
import time

try:
    import requests
except ImportError:
    print("نیاز به requests:  pip install requests")
    sys.exit(1)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(BASE, "diagnose_report.txt")

H = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "fa-IR,fa;q=0.9,en;q=0.8",
}

_lines = []


def say(*a):
    s = " ".join(str(x) for x in a)
    try:
        print(s)
    except Exception:
        print(s.encode("ascii", "replace").decode())
    _lines.append(s)


def get(name, url, params=None, timeout=15, show_json=0):
    say("")
    say("-" * 72)
    say("▶ " + name)
    say("  URL:", url)
    if params:
        say("  params:", json.dumps(params, ensure_ascii=False))
    t0 = time.time()
    try:
        r = requests.get(url, params=params, headers=H, timeout=timeout)
    except Exception as e:
        say("  ❌ خطا:", type(e).__name__, "-", str(e)[:220])
        return None
    dt = round(time.time() - t0, 1)
    say("  ✅ HTTP", r.status_code, "| اندازه:", len(r.content), "بایت |", dt, "ثانیه")
    if r.status_code != 200:
        say("  پاسخ:", r.text[:300].replace("\n", " "))
        return None
    try:
        data = r.json()
    except Exception:
        say("  ⚠️ پاسخ JSON نیست. ۳۰۰ کاراکتر اول:")
        say("  ", r.text[:300].replace("\n", " "))
        return None
    if show_json:
        txt = json.dumps(data, ensure_ascii=False)[:show_json]
        say("  نمونه JSON:", txt)
    return data


def main():
    q = sys.argv[1] if len(sys.argv) > 1 else "گوشی سامسونگ گلکسی اس24 اولترا"
    say("=" * 72)
    say("  گزارش تشخیصی — جستجوگر قیمت")
    say("  زمان:", time.strftime("%Y-%m-%d %H:%M:%S"))
    say("  عبارت جستجو:", q)
    say("  پایتون:", sys.version.split()[0])
    say("=" * 72)

    # ---------------------------------------------------------- ترب
    say("\n\n████ ۱. ترب — جستجو ████")
    d = get("ترب /v4/base-product/search/",
            "https://api.torob.com/v4/base-product/search/",
            {"page": 0, "size": 24, "sort": "popularity", "q": q, "query": q,
             "source": "next_desktop"})
    torob_key = None
    if d:
        say("  کلیدهای سطح اول:", list(d)[:15])
        res = d.get("results") or []
        say("  تعداد نتایج:", len(res))
        if res:
            it = res[0]
            say("  کلیدهای هر نتیجه:", list(it))
            for i, it in enumerate(res[:3]):
                say(f"  [{i}] نام: {it.get('name1') or it.get('name2')}")
                say(f"      price={it.get('price')!r}   price_text={it.get('price_text')!r}")
                say(f"      shop={it.get('shop_name') or it.get('shop_text') or it.get('shop')!r}")
                say(f"      url={(it.get('web_client_absolute_url') or '')[:90]}")
            torob_key = (res[0].get("prk") or res[0].get("random_key")
                         or res[0].get("id") or res[0].get("product_key"))
            say("  کلید محصول (prk) اولین نتیجه:", torob_key)
            say("  آدرس صفحه بعد:", str(d.get("next"))[:110])
        else:
            say("  ⚠️ هیچ نتیجه‌ای برنگشت")

    # ---------------------------------------------------------- ترب — جزئیات
    if torob_key:
        say("\n\n████ ۲. ترب — صفحه‌ی محصول (همه‌ی فروشنده‌ها) ████")
        for label, url in [
            ("product-page", "https://api.torob.com/v4/product-page/"),
            ("base-product/details", "https://api.torob.com/v4/base-product/details/"),
        ]:
            data = get(f"ترب {label}", url, {"prk": torob_key}, show_json=0)
            if data:
                say("  کلیدها:", list(data)[:25])
                for k in ("lowPriceRial", "highPriceRial", "priceRial", "offerCount",
                          "productName", "min_price", "max_price", "price", "sellers"):
                    if k in data:
                        say(f"  {k} = {json.dumps(data[k], ensure_ascii=False)[:200]}")
                s2 = data.get("sellers") or data.get("results") or []
                if isinstance(s2, list) and s2:
                    say("  تعداد فروشنده:", len(s2), "| کلیدها:", list(s2[0]))
                break

    # ---------------------------------------------------------- دیجی‌کالا
    say("\n\n████ ۳. دیجی‌کالا — جستجو ████")
    dk = get("دیجی‌کالا /v1/search/", "https://api.digikala.com/v1/search/",
             {"q": q, "page": 1})
    dk_id = None
    if dk:
        say("  کلیدهای سطح اول:", list(dk)[:15])
        data = dk.get("data") or {}
        say("  کلیدهای data:", list(data)[:15])
        prods = data.get("products") or []
        say("  تعداد محصول:", len(prods))
        if prods:
            p = prods[0]
            say("  کلیدهای محصول:", list(p)[:40])
            for i, p in enumerate(prods[:3]):
                say(f"  [{i}] {p.get('title_fa')}")
                say(f"      id={p.get('id')}")
                dv = p.get("default_variant") or {}
                say(f"      default_variant.price = {json.dumps(dv.get('price'), ensure_ascii=False)}")
                say(f"      seller = {(p.get('seller') or {}).get('title')!r}")
                say(f"      url = {(p.get('url') or {}).get('uri')!r}")
            dk_id = prods[0].get("id")
        else:
            say("  ⚠️ محصولی برنگشت (احتمالاً محدودیت/بلاک)")
        pager = (dk.get("data") or {}).get("pager") or {}
        say("  pager:", json.dumps(pager, ensure_ascii=False)[:200])

    if dk_id:
        say("\n\n████ ۴. دیجی‌کالا — صفحه‌ی محصول ████")
        for ver in (2, 1):
            data = get(f"دیجی‌کالا /v{ver}/product/",
                       f"https://api.digikala.com/v{ver}/product/{dk_id}/")
            if data:
                say("  کلیدها:", list(data)[:20])
                prod = (data.get("data") or {}).get("product") or data.get("product") or {}
                say("  عنوان:", prod.get("title_fa"))
                say("  price:", json.dumps(prod.get("price"), ensure_ascii=False)[:300])
                dv = prod.get("default_variant") or {}
                say("  default_variant.price:", json.dumps(dv.get("price"), ensure_ascii=False)[:300])
                break

    # --------------------------------------------------- تستِ واقعیِ کلکسیونرها
    say("\n\n████ ۵. تستِ کلکسیونرهای خودِ برنامه ████")
    sys.path.insert(0, BASE)
    try:
        from collectors import torob, digikala
        from core.matcher import parse as parse_title
        for label, mod in (("ترب", torob), ("دیجی کالا", digikala)):
            say(f"\n  --- {label} ---")
            try:
                offs = mod.fetch(q, pages=1, timeout=12)
            except Exception as e:
                say(f"  ❌ {label} خطا داد: {type(e).__name__}: {str(e)[:200]}")
                continue
            say(f"  تعداد پیشنهادِ دریافت‌شده: {len(offs)}")
            ok_price = sum(1 for o in offs if o.price)
            ok_title = sum(1 for o in offs if o.title.strip())
            say(f"  با عنوان: {ok_title} | با قیمت: {ok_price}")
            for o in offs[:5]:
                say(f"    • {o.title[:70]}")
                say(f"      قیمت={o.price} | فروشنده={o.seller!r} | extra={o.extra}")
            if offs and offs[0].title:
                say("  تجزیه‌ی اولین عنوان:", json.dumps(
                    {k: v for k, v in parse_title(offs[0].title).items()
                     if k in ("brand", "model_label", "caps", "category", "accessory")},
                    ensure_ascii=False))
    except Exception as e:
        say("  ❌ نتوانستم کلکسیونرها را اجرا کنم:", type(e).__name__, str(e)[:200])

    say("\n  --- اجرای کاملِ خط لوله (هر دو منبع) ---")
    try:
        from pipeline import run_search
        res = run_search(q, mode="auto", pages=1)
        say("  منابع موفق:", json.dumps(res.get("sources_ok"), ensure_ascii=False))
        say("  خطاها:", json.dumps(res.get("errors"), ensure_ascii=False))
        say("  آمارِ هر منبع:", json.dumps(res["result"].get("by_source"), ensure_ascii=False))
        say("  تعداد گروه‌ها:", len(res["result"]["groups"]))
        for g in res["result"]["groups"][:3]:
            say(f"    • {g['label']} | {g['min']} → {g['max']} | {g['count']} فروشنده")
    except Exception as e:
        say("  ❌ خطا در خط لوله:", type(e).__name__, str(e)[:200])

    # ---------------------------------------------------------- خلاصه
    say("\n\n" + "=" * 72)
    say("  پایان گزارش. فایل ذخیره شد:")
    say("  " + OUT)
    say("=" * 72)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        _lines.append(traceback.format_exc())
        print(traceback.format_exc())
    finally:
        try:
            with open(OUT, "w", encoding="utf-8") as fh:
                fh.write("\n".join(_lines))
            print("\n📄 گزارش در", OUT)
        except Exception as e:
            print("نتوانستم فایل را بنویسم:", e)
