#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ساختِ جدولِ سایت‌ها و فروشنده‌ها (CSV + اکسل) از روی data/shops.json"""

import csv
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOPS = os.path.join(BASE, "data", "shops.json")
CSV_OUT = os.path.join(BASE, "data", "sites_and_shops.csv")
XLSX_OUT = os.path.join(BASE, "data", "sites_and_shops.xlsx")

HEADERS = ["ردیف", "نوع", "نام", "نقش / دسته", "شماره تماس", "لینک", "فروشنده در ترب؟"]


def build_rows(data):
    rows, i = [], 0
    for s in data.get("data_sources", []):
        i += 1
        rows.append([i, "منبع داده", s["name"], s.get("role", ""),
                     s.get("phone", "—"), s.get("url", ""), "—"])
    for s in data.get("shops", []):
        i += 1
        rows.append([i, "فروشگاه", s["name"], s.get("category", ""),
                     s.get("phone", "—"), s.get("url", ""),
                     "بله" if s.get("in_torob") else "خیر"])
    return rows


def write_csv(rows):
    with open(CSV_OUT, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(HEADERS)
        w.writerows(rows)
    print("  ✓", CSV_OUT)


def write_xlsx(rows):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill
    except ImportError:
        print("  (اکسل ساخته نشد: pip install openpyxl)")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = "سایت‌ها و فروشنده‌ها"
    ws.sheet_view.rightToLeft = True

    head_fill = PatternFill("solid", fgColor="1F4E79")
    ws.append(HEADERS)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF", size=12)
        c.fill = head_fill
        c.alignment = Alignment(horizontal="center", vertical="center")

    for r in rows:
        ws.append(r)

    widths = [6, 12, 20, 28, 24, 38, 16]
    for idx, w in enumerate(widths, start=1):
        ws.column_dimensions[chr(64 + idx)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(horizontal="right", vertical="center")
    ws.freeze_panes = "A2"
    wb.save(XLSX_OUT)
    print("  ✓", XLSX_OUT)


def main():
    with open(SHOPS, encoding="utf-8") as fh:
        data = json.load(fh)
    rows = build_rows(data)
    print(f"  {len(rows)} سطر ساخته شد")
    write_csv(rows)
    write_xlsx(rows)

    print("\n  خلاصه:")
    for r in rows:
        print(f"   {r[0]:2d}. [{r[1]}] {r[2]:<18} {r[4]:<22} {r[5]}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
