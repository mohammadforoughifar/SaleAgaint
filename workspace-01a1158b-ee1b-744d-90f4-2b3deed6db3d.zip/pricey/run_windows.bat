@echo off
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

echo.
echo    ==========================================
echo      Price Finder  -  Torob ^& Digikala
echo    ==========================================
echo.

rem --- پیدا کردن پایتون واقعی ---
rem (نسخه‌ی قلابی که فروشگاه مایکروسافت را باز می‌کند را رد می‌کنیم)
set "PY="
set "TRY=py -3"
call :check
if defined PY goto :run

set "TRY=python"
call :check
if defined PY goto :run

set "TRY=python3"
call :check
if defined PY goto :run

goto :nopy


:check
%TRY% --version >nul 2>nul
if not errorlevel 1 set "PY=%TRY%"
goto :eof


:run
echo    Python found: %PY%
echo    Starting the server... (the first run installs packages)
echo    If no browser opens, type the address below in your browser.
echo.

%PY% -u run.py
if errorlevel 1 (
  echo.
  echo    [ERROR] The program stopped. See  run_log.txt  for details.
)
goto :end


:nopy
echo    [ERROR] Python is not installed on this computer.
echo.
echo    Do this once:
echo      1. Open          https://www.python.org/downloads/
echo      2. Download      Python 3.12  and run the installer
echo      3. IMPORTANT:    tick the box  "Add Python to PATH"
echo      4. Then double-click this file again
echo.


:end
echo.
echo    ==========================================
echo    Press any key to close this window...
echo    ==========================================
pause >nul
exit /b 0
