#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
اجرای آسانِ «جستجوگر قیمت»
----------------------------
نسخه‌ی مقاوم: هر خطایی را در run_log.txt می‌نویسد و پنجره را ناگهانی نمی‌بندد.
"""

import os
import sys
import socket
import subprocess
import threading
import traceback
import webbrowser

# --- خروجی را حتماً UTF-8 کن (ویندوز با فارسی/ایموجی مشکل دارد) ---
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

BASE = os.path.dirname(os.path.abspath(__file__))
REQ = os.path.join(BASE, "requirements.txt")
LOG = os.path.join(BASE, "run_log.txt")
NEEDED = ["fastapi", "uvicorn", "requests", "rapidfuzz"]

try:                                  # لاگ را از نو بنویس
    with open(LOG, "w", encoding="utf-8") as fh:
        fh.write("=== Price Finder log ===\n")
        fh.write("python: %s\n" % sys.version)
        fh.write("folder: %s\n\n" % BASE)
except Exception:
    pass


def say(*a):
    msg = " ".join(str(x) for x in a)
    try:
        print(msg)
    except Exception:
        print(msg.encode("ascii", "replace").decode())
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(msg + "\n")
    except Exception:
        pass


def bar(ch="-", n=52):
    say(ch * n)


def installed(mod):
    import importlib.util
    try:
        return importlib.util.find_spec(mod) is not None
    except Exception:
        return False


def ensure_deps():
    missing = [m for m in NEEDED if not installed(m)]
    if not missing:
        say("  [OK] all packages already installed")
        return True
    say("  installing:", ", ".join(missing))
    say("  (only the first time, takes a few seconds)")
    cmd = [sys.executable, "-m", "pip", "install", "-r", REQ]
    try:
        subprocess.check_call(cmd)
        say("  [OK] install finished")
        return True
    except Exception as e:
        say("  [ERROR] automatic install failed:", e)
        say("  run this manually in a terminal:")
        say("     pip install -r requirements.txt")
        return False


def free_port(start=8000, tries=12):
    for p in range(start, start + tries):
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", p))
            return p
        except OSError:
            continue
        finally:
            s.close()
    return start


def main():
    bar()
    say("  Price Finder  --  Torob + Digikala")
    bar()

    if sys.version_info < (3, 9):
        say("  [ERROR] Python 3.9+ required. You have:", sys.version.split()[0])
        return 1

    os.chdir(BASE)
    sys.path.insert(0, BASE)

    if not ensure_deps():
        return 1

    port = free_port(8000)
    url = "http://localhost:%d" % port
    bar()
    say("  READY!  opening browser:  " + url)
    say("  to stop: press Ctrl+C (or close this window)")
    bar()
    say("")

    threading.Timer(2.0, lambda: webbrowser.open(url)).start()

    import uvicorn
    from app import app
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
    return 0


if __name__ == "__main__":
    code = 0
    try:
        code = main()
    except KeyboardInterrupt:
        say("\n  Bye!")
    except Exception:
        say("  [CRASH] something went wrong:\n")
        say(traceback.format_exc())
        code = 1
    finally:
        if code:
            say("")
            say("  details saved in: " + LOG)
            try:
                input("\n  Press Enter to close...")
            except Exception:
                pass
        sys.exit(code)
