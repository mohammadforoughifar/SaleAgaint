"""
🔔 دیده‌بانِ قیمت — رباتِ پیگیری خودکار
----------------------------------------
هر چند دقیقه/ساعت یک کالا را دوباره جستجو می‌کند،
تاریخچه‌ی قیمت را نگه می‌دارد و وقتی ارزان شد اعلان می‌سازد.
"""

import json
import os
import threading
import time
import uuid
from datetime import datetime

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WATCH_FILE = os.path.join(BASE, "data", "watches.json")


def iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


class Watcher:
    def __init__(self, path: str = WATCH_FILE):
        self.path = path
        self.lock = threading.RLock()
        self.state = {"watches": [], "alerts": []}
        self._stop = False
        self.thread = None
        self.load()

    # ---------------------------------------------------------- ذخیره‌سازی
    def load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                self.state = json.load(fh)
            self.state.setdefault("watches", [])
            self.state.setdefault("alerts", [])
        except Exception:
            self.state = {"watches": [], "alerts": []}

    def save(self):
        with self.lock:
            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                with open(self.path, "w", encoding="utf-8") as fh:
                    json.dump(self.state, fh, ensure_ascii=False, indent=1)
            except Exception:
                pass

    # ---------------------------------------------------------- مدیریت
    def add(self, query, target=None, interval=60, sources="ترب,دیجی کالا",
            mode="auto", drop_pct=3):
        with self.lock:
            w = {
                "id": uuid.uuid4().hex[:8],
                "query": (query or "").strip(),
                "target": int(target) if target else None,
                "interval": max(1, int(interval or 60)),
                "sources": sources, "mode": mode,
                "drop_pct": max(1, int(drop_pct or 3)),
                "created": iso(), "last_run": None,
                "last_min": None, "last_median": None, "last_count": 0,
                "label": "", "best_url": "", "error": "",
                "history": [],
            }
            self.state["watches"].append(w)
            self.save()
            return w

    def remove(self, wid):
        with self.lock:
            before = len(self.state["watches"])
            self.state["watches"] = [w for w in self.state["watches"] if w["id"] != wid]
            self.save()
            return len(self.state["watches"]) < before

    def get(self, wid):
        for w in self.state["watches"]:
            if w["id"] == wid:
                return w
        return None

    # ---------------------------------------------------------- اجرا
    def run(self, wid) -> dict:
        """یک دیده‌بان را همین حالا بررسی می‌کند"""
        from pipeline import run_search

        w = self.get(wid)
        if not w:
            return {"error": "پیدا نشد"}
        try:
            srcs = [s.strip() for s in (w.get("sources") or "").split(",") if s.strip()]
            data = run_search(w["query"], srcs, w.get("mode", "auto"), deep=True)
            groups = data["result"].get("groups") or []
            if not groups:
                w["error"] = "هیچ نتیجه‌ای پیدا نشد"
                w["last_run"] = iso()
                self.save()
                return {"ok": False, "error": w["error"]}

            g = groups[0]
            prev_min = w.get("last_min")
            w["last_run"] = iso()
            w["last_min"] = g["min"]
            w["last_median"] = g["median"]
            w["last_count"] = g["count"]
            w["label"] = g["label"]
            w["best_url"] = (g["offers"][0]["url"] if g["offers"] else "")
            w["error"] = ""
            w.setdefault("history", []).append(
                {"t": iso(), "min": g["min"], "median": g["median"], "count": g["count"]})
            w["history"] = w["history"][-120:]

            self._check_alerts(w, prev_min)
            self.save()
            return {"ok": True, "min": g["min"], "label": g["label"]}
        except Exception as e:                                   # noqa: BLE001
            w["error"] = f"{type(e).__name__}: {str(e)[:120]}"
            w["last_run"] = iso()
            self.save()
            return {"ok": False, "error": w["error"]}

    def _check_alerts(self, w, prev_min):
        new_min = w["last_min"]
        msgs = []

        # ۱) رسیدن به قیمتِ هدف
        tgt = w.get("target")
        if tgt and new_min <= tgt and (prev_min is None or prev_min > tgt):
            msgs.append(("target",
                         f"🎯 «{w['query']}» به هدف رسید — {new_min:,} تومان (هدف شما: {tgt:,})"))
        # ۲) افتِ نسبت به قبل
        if prev_min and new_min < prev_min:
            pct = (1 - new_min / prev_min) * 100
            if pct >= w.get("drop_pct", 3):
                msgs.append(("drop",
                             f"📉 «{w['query']}» {round(pct)}٪ ارزان شد — "
                             f"{prev_min:,} → {new_min:,} تومان"))
        # ۳) اگر این افت، رکوردِ کمترینِ تاریخچه هم هست، در همان پیام بگو
        #    (فقط وقتی از آستانه‌ی افت گذشته باشد — وگرنه نویز می‌شود)
        if msgs and msgs[-1][0] == "drop":
            older = [h["min"] for h in w.get("history", [])][:-1]
            if older and new_min < min(older):
                kind, text = msgs[-1]
                msgs[-1] = (kind, text + "  🏅 کمترینِ تاریخچه!")

        for kind, msg in msgs:
            self.state["alerts"].insert(0, {
                "id": uuid.uuid4().hex[:8], "watch_id": w["id"],
                "query": w["query"], "kind": kind, "message": msg,
                "t": iso(), "read": False, "url": w.get("best_url", ""),
                "price": new_min,
            })
        self.state["alerts"] = self.state["alerts"][:60]

    # ---------------------------------------------------------- زمان‌بند
    def _due(self, w) -> bool:
        if not w.get("last_run"):
            return True
        try:
            last = datetime.strptime(w["last_run"], "%Y-%m-%d %H:%M")
        except Exception:
            return True
        need = max(1, int(w.get("interval") or 60)) * 60
        return (datetime.now() - last).total_seconds() >= need

    def loop(self, every: int = 20):
        while not self._stop:
            try:
                for w in list(self.state["watches"]):
                    if self._stop:
                        break
                    if self._due(w):
                        try:
                            self.run(w["id"])
                        except Exception:                        # noqa: BLE001
                            pass
                        time.sleep(1)
            except Exception:                                    # noqa: BLE001
                pass
            time.sleep(every)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self._stop = False
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()

    def stop(self):
        self._stop = True

    # ---------------------------------------------------------- خروجی
    def snapshot(self) -> dict:
        with self.lock:
            unread = sum(1 for a in self.state["alerts"] if not a.get("read"))
            return {
                "watches": self.state["watches"],
                "alerts": self.state["alerts"][:25],
                "unread": unread,
            }

    def mark_read(self):
        with self.lock:
            for a in self.state["alerts"]:
                a["read"] = True
            self.save()


WATCHER = Watcher()
