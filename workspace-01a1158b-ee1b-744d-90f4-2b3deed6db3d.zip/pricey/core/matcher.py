"""
ایستگاه ③ و ④  —  امتیازدهنده و گروه‌بند
اینجا تصمیم می‌گیریم هر نتیجه «همان کالاست یا نه».
"""

from dataclasses import dataclass, field
from statistics import median, mean
from collections.abc import Iterable
from core.normalize import parse, norm_tokens_for_match, infer_category

try:
    from rapidfuzz import fuzz
    def _sim(a: str, b: str) -> float:
        return fuzz.token_set_ratio(a, b) / 100.0
except Exception:                                    # اگر rapidfuzz نصب نبود
    from difflib import SequenceMatcher
    def _sim(a: str, b: str) -> float:
        return SequenceMatcher(None, a, b).ratio()

MATCH_MIN = 42          # حد نصابِ ورود به جدول
FUZZY_NEAR = 0.90       # آستانه‌ی شباهتِ دو واژه (برای غلط‌املایی)


@dataclass
class Offer:
    title: str
    price: int | None            # به تومان
    seller: str = ""
    url: str = ""
    source: str = ""
    image: str = ""
    extra: dict = field(default_factory=dict)   # prk / id برای گرفتنِ جزئیات


@dataclass
class Scored:
    offer: Offer
    parsed: dict
    score: float = 0.0
    reject: str | None = None
    acc_ok: bool = True
    group_key: tuple = ()
    group_label: str = ""


# ------------------------------------------------------------------ امتیازدهی
def _token_seen(tok: str, parsed: dict) -> bool:
    if tok in parsed["tokens"]:
        return True
    for t in parsed["tokens"]:
        if abs(len(t) - len(tok)) <= 2 and _sim(tok, t) >= FUZZY_NEAR:
            return True
    return False


def score(q: dict, o: dict) -> tuple[float, str | None]:
    """امتیاز ۰..۱۰۰ و دلیلِ رد شدن (اگر رد شده)"""

    # — ردهای سخت ——————————————————————————————————————
    if o["accessory"] and not (o["accessory"] & q["accessory"]):
        return 0.0, "accessory"                       # قاب/گلس/شارژر به‌جای خود کالا
    if q["brand"] and o["brand"] and q["brand"] != o["brand"]:
        return 0.0, "brand"                           # برند فرق دارد
    if q["category"] and o["category"] and q["category"] != o["category"]:
        return 0.0, "category"                        # گوشی با لپ‌تاپ قاطی نشود
    if o["price"] is None or o["price"] <= 0:
        return 0.0, "no_price"

    # — شماره‌ی مدل باید دقیقاً یکی باشد ————————————————
    # «S24» با «S26» و «A07» با «A17» یکی نیست، حتی اگر بقیه‌ی
    # کلمه‌ها (ultra/256/سامسونگ) مشترک باشند.
    q_num = q.get("model_num") or set()
    o_num = o.get("model_num") or set()
    if q_num and o_num and not (q_num & o_num):
        return 0.0, "model"

    # — تیپ/پسوند هم باید هم‌خوان باشد ————————————————
    # «Ultra» با «FE» فرق دارد؛ «Pro Max» با «Pro» هم.
    q_var = q.get("variant") or set()
    o_var = o.get("variant") or set()
    if q_var and o_var and not (q_var & o_var):
        return 0.0, "variant"

    # — پوششِ واژه‌های کلیدی ————————————————————————————
    core = norm_tokens_for_match(q)
    if core:
        hits = sum(1 for t in core if _token_seen(t, o))
        cov = hits / len(core)
    else:
        hits, cov = 1, 1.0

    fuzzy = _sim(q["atext"], o["atext"])
    if hits == 0 and fuzzy < 0.70:
        return 0.0, "low_score"

    s = 100.0 * (0.60 * cov + 0.40 * fuzzy)

    # اگر کاربر دنبالِ یک وسیله‌ی جانبی است، خودِ کالا را عقب بزن
    if q["accessory"] and not (o["accessory"] & q["accessory"]):
        s -= 45

    # — هم‌ترازی مدل و تیپ ————————————————————————————
    if q_num and o_num and (q_num & o_num):
        s += 10                                       # کدِ مدل یکی است
    if q_var and o_var:
        if q_var & o_var:
            s += 6                                    # تیپ هم‌خوان است
        if not (q_var <= o_var):
            s -= 15                                   # تیپِ خواسته‌شده کامل نیست
    elif q_var and not o_var:
        s -= 8                                        # نتیجه تیپ را نگفته است
    # — ظرفیت و رم ——————————————————————————————————
    q_cap = q["caps"][-1] if q["caps"] else None
    o_cap = o["caps"][-1] if o["caps"] else None
    if q_cap and o_cap:
        s += 8 if q_cap == o_cap else 0
    if q["ram"] and o["ram"] and q["ram"] != o["ram"]:
        s -= 10
    # — رنگ ——————————————————————————————————————————
    if q["color"] and o["color"] and q["color"] != o["color"]:
        s -= 15

    s = max(0.0, min(100.0, s))
    return (s, None) if s >= MATCH_MIN else (s, "low_score")


# ------------------------------------------------------------------ گروه‌بندی
def _cap_label(cap: int | None) -> str:
    if not cap:
        return ""
    if cap >= 1024 and cap % 1024 == 0:
        return f"{cap // 1024} ترابایت"
    return f"{cap} گیگابایت"


def group_key_of(q: dict, p: dict) -> tuple:
    cap = p["caps"][-1] if p["caps"] else None
    color = p["color"] if q["color"] else None
    return (p["model_label"] or "?", cap or 0, color or "")


def group_label_of(key: tuple) -> str:
    model, cap, color = key
    parts = []
    if model and model != "?":
        parts.append(model)
    if cap:
        parts.append(_cap_label(cap))
    if color:
        parts.append(color)
    return " · ".join(parts) if parts else "سایر"


# ------------------------------------------------------------------ آمار
def drop_outliers(values: list[int]) -> tuple[list[int], list[int]]:
    """حذف قیمت‌های مسخره (۱ تومنی یا ۱۰ برابری) با روش IQR"""
    if len(values) < 5:
        return values, []
    sv = sorted(values)
    n = len(sv)

    def pct(p: float) -> float:
        k = (n - 1) * p
        f, c = int(k), min(int(k) + 1, n - 1)
        return sv[f] + (sv[c] - sv[f]) * (k - f)

    q1, q3 = pct(0.25), pct(0.75)
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    kept = [v for v in values if lo <= v <= hi]
    gone = [v for v in values if not (lo <= v <= hi)]
    return (kept, gone) if kept else (values, [])


# ------------------------------------------------- سنجش با منابعِ مرجع
# ترب و دیجی‌کالا «مبنای» قیمت‌اند: ترب خودش ده‌ها فروشنده را جمع می‌کند
# و دیجی‌کالا فروشگاهِ بزرگِ شناخته‌شده‌ای است. بقیه‌ی منابع با این دو
# سنجیده می‌شوند — اگر قیمتشان از بازه‌ی این دو خیلی بیرون بزند،
# «غیرمتعارف» حساب می‌شود و نمایش داده نمی‌شود (مثلاً جنسِ «های کپی»
# که یک‌دهمِ قیمتِ اصلی است، یا باندل‌های گران‌قیمت).
REFERENCE_SOURCES = {"ترب", "دیجی کالا"}
ABNORMAL_FACTOR = 0.30      # ۳۰٪ دورتر از بازه‌ی مرجع = غیرمتعارف
NON_ORIGINAL = ("های کپی", "هایکپی", "های کپی", "کپی ", "استوک", "stock ",
                "رفربیشد", "refurbished", "غیر اورجینال", "غیراورجینال")


def _is_non_original(title: str) -> bool:
    t = (title or "").lower()
    return any(k in t for k in NON_ORIGINAL)


def _ref_band(items: list["Scored"]):
    """
    بازه‌ی قابل‌قبولِ قیمت بر اساسِ منابعِ مرجع.
    اگر هیچ پیشنهادی از ترب/دیجی‌کالا نباشد، None برمی‌گرداند
    (یعنی مبنایی نداریم و چیزی را به این دلیل حذف نمی‌کنیم).
    """
    refs = [i.offer.price for i in items
            if i.offer.source in REFERENCE_SOURCES and i.offer.price]
    if not refs:
        return None
    lo = min(refs) * (1 - ABNORMAL_FACTOR)
    hi = max(refs) * (1 + ABNORMAL_FACTOR)
    return lo, hi, len(refs)


def drop_abnormal(items: list["Scored"]) -> tuple[list["Scored"], list["Scored"]]:
    """
    پیشنهادهای غیرمتعارف را از بقیه جدا می‌کند:
      · قیمت بیرون از بازه‌ی منابعِ مرجع
      · کالای غیرِاصل (های کپی / استوک) وقتی مرجع داریم
    خودِ منابعِ مرجع هرگز حذف نمی‌شوند.
    """
    band = _ref_band(items)
    if not band:
        # مرجعی نداریم → قیمت را نمی‌توانیم قضاوت کنیم. اما هنوز می‌توانیم
        # کالای غیرِاصل («های کپی»/استوک) را از کالای اصل جدا کنیم.
        orig = [i for i in items if not _is_non_original(i.offer.title)]
        non = [i for i in items if _is_non_original(i.offer.title)]
        return (orig, non) if orig and non else (items, [])
    lo, hi, _ = band
    keep, out = [], []
    for i in items:
        p = i.offer.price
        if p is None:
            keep.append(i)
            continue
        if i.offer.source in REFERENCE_SOURCES:
            keep.append(i)
            continue
        if not (lo <= p <= hi) or _is_non_original(i.offer.title):
            out.append(i)
        else:
            keep.append(i)
    # هیچ‌وقت همه را حذف نمی‌کنیم — اگر مرجع نادرست بود، داده می‌ماند
    return (keep, out) if keep else (items, [])


def _offer_dict(sc: Scored) -> dict:
    o = sc.offer
    return {
        "title": o.title, "price": o.price,
        "seller": o.seller or o.source, "url": o.url,
        "source": o.source, "score": sc.score,
    }


def build_group(q: dict, key: tuple, items: list[Scored], deep: bool = False) -> dict:
    """آمار و نمای یک گروه را می‌سازد"""
    items = sorted(items, key=lambda x: (x.offer.price is None, x.offer.price or 0))

    # ۱) قیمت‌های غیرمتعارفِ منابعِ غیرمرجع را کنار بگذار (مبنای: ترب/دیجی‌کالا)
    items, abnormal = drop_abnormal(items)
    band = _ref_band(items)

    # ۲) داده‌های پرتِ آماری (۱ تومنی / ۱۰ برابری)
    all_prices = [i.offer.price for i in items]
    # در حالتِ عمیق همه‌ی قیمت‌ها واقعی‌اند → چیزی را «داده‌ی پرت» حساب نمی‌کنیم
    kept, gone = (all_prices, []) if deep else drop_outliers(all_prices)
    kept_set = set(kept)
    items_kept = [i for i in items if i.offer.price in kept_set] or items

    q_cap = q["caps"][-1] if q["caps"] else None
    g_cap = key[1] or None
    exact = True
    if q["model"] and key[0] != (q["model_label"] or "?"):
        exact = False
    if q_cap and g_cap != q_cap:
        exact = False
    if q["accessory"] and not all(i.acc_ok for i in items_kept):
        exact = False

    avg_score = sum(i.score for i in items_kept) / len(items_kept)
    rank = 0.6 * avg_score + (40 if exact else 0)

    return {
        "label": group_label_of(key),
        "model": key[0], "capacity": key[1] or None, "color": key[2] or "",
        "exact": exact, "deep": deep,
        "count": len(items_kept),
        "min": min(i.offer.price for i in items_kept),
        "max": max(i.offer.price for i in items_kept),
        "median": int(median([i.offer.price for i in items_kept])),
        "mean": int(mean([i.offer.price for i in items_kept])),
        "score": round(avg_score, 1),
        "rank": round(rank, 1),
        "outliers": sorted(gone),
        "ref_n": band[2] if band else 0,
        "ref_span": [int(band[0]), int(band[1])] if band else None,
        "abnormal": [{"price": i.offer.price, "source": i.offer.source,
                      "title": i.offer.title} for i in abnormal],
        "offers": [_offer_dict(i) for i in items_kept],
        "_items": items_kept,
        "_key": key,
    }


# ------------------------------------------------------------------ خط لوله
def analyze(query: str, offers: Iterable[Offer]) -> dict:
    q = parse(query)
    q["price"] = None
    # اگر کاربر دسته را ننوشته («سامسونگ اس 24 اولترا»)، از روی کدِ مدل
    # حدس می‌زنیم — وگرنه تبلت و لپ‌تاپ هم برای جستجوی گوشی می‌آمدند.
    if not q.get("category"):
        q["category"] = infer_category(q["atext"], q["tokens"], q.get("model_num") or set())

    scored: list[Scored] = []
    rejected = {"accessory": 0, "brand": 0, "category": 0, "model": 0,
                "variant": 0, "low_score": 0, "no_price": 0}
    by_source: dict[str, dict] = {}

    for off in offers:
        src = off.source or "نامشخص"
        st = by_source.setdefault(src, {"fetched": 0, "matched": 0})
        st["fetched"] += 1
        p = parse(off.title)
        p["price"] = off.price
        s, why = score(q, p)
        sc = Scored(offer=off, parsed=p, score=round(s, 1), reject=why,
                    acc_ok=bool(q["accessory"] & p["accessory"]) if q["accessory"] else True)
        if why:
            rejected[why] = rejected.get(why, 0) + 1
            continue
        st["matched"] += 1
        sc.group_key = group_key_of(q, p)
        sc.group_label = group_label_of(sc.group_key)
        scored.append(sc)

    buckets: dict[tuple, list[Scored]] = {}
    for sc in scored:
        buckets.setdefault(sc.group_key, []).append(sc)

    groups = [build_group(q, key, items) for key, items in buckets.items()]
    groups.sort(key=lambda g: (-g["exact"], -g["rank"], -g["count"]))

    return {
        "query": query,
        "parsed": {
            "brand": q["brand"], "model": q["model_label"],
            "caps": q["caps"], "category": q["category"], "color": q["color"],
        },
        "total": len(list(offers)) if not isinstance(offers, list) else len(offers),
        "matched": len(scored),
        "rejected": rejected,
        "by_source": by_source,
        "groups": groups,
        "_q": q,
    }


def strip_internal(result: dict) -> dict:
    """چیزهای غیرقابلِ تبدیل به JSON را قبل از ارسال حذف می‌کند"""
    for g in result.get("groups", []):
        g.pop("_items", None)
        g.pop("_key", None)
    result.pop("_q", None)
    return result
