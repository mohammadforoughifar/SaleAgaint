"""
ایستگاه ②  —  نرمال‌ساز
همه‌ی عنوان‌ها را به یک الفبای واحد می‌بریم تا:
  «گلکسی S24 Ultra»  ==  «Galaxy S24 Ultra»  ==  «گلکشی اس24 اولترا»
"""

import re

# ---------------------------------------------------------------- یک‌دست‌سازی حروف
CHAR_MAP = {
    "ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه", "ؤ": "و",
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ء": "",
    "ـ": " ",                      # کشیده
    "‍": " ", "‌": " ",            # ZWJ / ZWNJ  →  فاصله
    "‎": "", "‏": "", "‪": "", "‬": "",
}
for _i, _d in enumerate("۰۱۲۳۴۵۶۷۸۹"):      # اعداد فارسی
    CHAR_MAP[_d] = str(_i)
for _i, _d in enumerate("٠١٢٣٤٥٦٧٨٩"):      # اعداد عربی
    CHAR_MAP[_d] = str(_i)
for _c in "ًٌٍَُِّْٰٕٔٓ":                 # اعراب
    CHAR_MAP[_c] = ""

# ---------------------------------------------------------------- معادل‌سازی واژه‌ها
PHRASE_ALIASES = {                 # چندواژه‌ای (قبل از توکن‌سازی)
    "پلی استیشن": "ps",
    "پلی استیشن": "ps",
    "ال جی": "lg",
    "اچ پی": "hp",
    "تلفن همراه": "گوشی",
    "لپ تاپ": "لپتاپ",
    "پلی استیشن": "ps", "پلاستیشن": "ps", "playstation": "ps",
    "ایکس باکس": "xbox", "اکس باکس": "xbox",
    "اسمارت واچ": "ساعت هوشمند",
    "هندزفری": "هندزفری",
}

WORD_ALIASES = {
    # برندها
    "سامسونگ": "samsung", "سامسونت": "samsung", "سمسونگ": "samsung",
    "اپل": "apple", "ایفون": "iphone", "آیفون": "iphone", "ایپد": "ipad", "مکبوک": "macbook",
    "شیائومی": "xiaomi", "شیاومی": "xiaomi", "ردمی": "redmi", "پوکو": "poco", "شائومی": "xiaomi",
    "ایسوس": "asus", "لنوو": "lenovo", "سونی": "sony", "هواوی": "huawei",
    "نوکیا": "nokia", "موتورولا": "motorola", "انکر": "anker", "دل": "dell",
    "تیوی": "tv", "الجی": "lg", "اچپی": "hp",
    # خانواده/مدل
    "گلکسی": "galaxy", "گلکشی": "galaxy", "گلکسی": "galaxy", "گلگسی": "galaxy",
    "اولترا": "ultra", "الترا": "ultra", "اولتراهای": "ultra",
    "پلاس": "plus", "پرو": "pro", "مکس": "max", "مینی": "mini",
    "نوت": "note", "فولد": "fold", "فلیپ": "flip", "لایت": "lite", "توربو": "turbo",
    # واحدها
    "گیگابایت": "gb", "گیگا": "gb", "گیگ": "gb",
    "ترابایت": "tb", "ترا": "tb",
    "مگابایت": "mb", "مگا": "mb",
    "رم": "ram",
}

# کلماتی که برای همه‌ی کالاها یکسان‌اند → وزن صفر در مقایسه
STOPWORDS = {
    "گوشی", "موبایل", "مدل", "ظرفیت", "سیم", "کارت", "سیمکارت", "دو", "تک", "سه", "چهار",
    "اورجینال", "اصل", "اصلی", "فابریک", "جدید", "نو", "آکبند", "ویتنام", "چین", "هند",
    "امارات", "گارانتی", "ماهه", "ماه", "سال", "روز", "رجیستر", "شده", "با", "و", "برای",
    "از", "به", "در", "رنگ", "رنگبندی", "بسته", "عدد", "عددی", "تومان", "ریال", "قیمت",
    "خرید", "فروش", "ویژه", "آفر", "تخفیف", "اینترنتی", "دارای", "موجود", "ارسال", "رایگان",
    "فوری", "بالا", "پک", "جعبه", "سری", "نسخه", "کد", "کالا", "محصول", "اسمارت", "هوشمند",
    "لپتاپ", "تبلت", "رام", "هارد", "اینچ", "وات", "ولت", "آمپر", "میلی", "آمپرساعت",
    "گارانتی", "ضمانت", "شرکت", "سازگار", "مناسب", "قابل", "هوشمند", "دیجیتال", "الکترونیک",
}

# لوازم جانبی: اگر در ابتدای عنوان باشد، یعنی خودِ کالا نیست
ACCESSORY_WORDS = {
    "قاب", "کاور", "کیس", "گلس", "محافظ", "صفحه", "شارژر", "آداپتور", "اداپتور", "کابل",
    "هندزفری", "هدفون", "هدست", "ایرپاد", "ایربادز", "اسپیکر", "بلندگو", "استند", "پایه",
    "بند", "قلم", "مموری", "کارت", "حافظه", "تبدیل", "رابط", "فندک", "پاوربانک", "باتری",
    "کیف", "کاور", "لمسی", "شیشه", "برچسب", "اسکین", "تمیز", "کننده", "کیت", "لوازم",
    "ماوس", "موش", "کیبورد", "صفحه", "کلید", "داک", "هاب", "مانیتور", "پایه", "نگهدارنده",
    "سیم", "کارت", "خوان", "هولدر", "گیری", "بگ", "ساک", "کوله",
}

# رنگ‌ها
COLORS = {
    "مشکی": "black", "سیاه": "black", "سفید": "white", "آبی": "blue", "سرمه ای": "navy",
    "سبز": "green", "قرمز": "red", "زرد": "yellow", "صورتی": "pink", "بنفش": "purple",
    "طوسی": "gray", "خاکستری": "gray", "نقره ای": "silver", "طلایی": "gold", "کرم": "cream",
    "قهوه ای": "brown", "تیتانیوم": "titanium", "تیتانیومی": "titanium", "نارنجی": "orange",
    "black": "black", "white": "white", "blue": "blue", "gray": "gray", "grey": "gray",
    "green": "green", "gold": "gold", "silver": "silver", "purple": "purple", "titanium": "titanium",
}

# دسته‌بندی کالا (برای اینکه گوشی با لپ‌تاپ قاطی نشود)
CATEGORIES = {
    "گوشی": ["گوشی", "موبایل", "تلفن همراه", "iphone", "galaxy s", "redmi note", "پوکو"],
    "لپ تاپ": ["لپتاپ", "نوت بوک", "نوتبوک", "macbook", "vivobook", "zenbook", "thinkpad", "ideapad"],
    "تبلت": ["تبلت", "ipad", "galaxy tab", "ایپد"],
    "ساعت هوشمند": ["ساعت هوشمند", "smartwatch", "watch"],
    "تلویزیون": ["تلویزیون", "tv"],
    "کنسول بازی": ["کنسول", "ps5", "ps4", "xbox", "پلی استیشن", "پلی استیشن"],
    "هدفون": ["هدفون", "هندزفری", "ایرپاد", "earbuds", "airpods"],
}

QUALIFIER_ORDER = ["pro", "max", "plus", "ultra", "mini", "fe", "note", "lite",
                   "fold", "flip", "turbo", "neo", "se", "air", "prime", "edge"]
QUALIFIERS = set(QUALIFIER_ORDER)

COMMON_CAPS = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048}


# ---------------------------------------------------------------- توابع اصلی
def normalize(text: str) -> str:
    """همه چیز را به متنِ استانداردِ کوچک و تمیز تبدیل می‌کند."""
    if not text:
        return ""
    t = "".join(CHAR_MAP.get(ch, ch) for ch in str(text))
    t = t.lower()
    for a, b in PHRASE_ALIASES.items():
        t = t.replace(a, b)
    # «اس 24» → «s24»   |   «پی اس 5» → «ps5»
    t = re.sub(r"\bاس\s*(\d{1,3})\b", r"s\1", t)
    t = re.sub(r"\bپی\s*اس\s*(\d)\b", r"ps\1", t)
    t = re.sub(r"\bps\s*(\d)\b", r"ps\1", t)
    t = re.sub(r"[^0-9a-zآ-ی\s]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def tokenize(norm_text: str) -> list[str]:
    toks = [w for w in norm_text.split(" ") if w]
    return [WORD_ALIASES.get(w, w) for w in toks]


def prettify_model(model_tokens: set[str]) -> str:
    """{'s24','ultra'} → 'S24 Ultra'   |   {'iphone','15','pro','max'} → 'iPhone 15 Pro Max'"""
    if not model_tokens:
        return ""
    base, quals = "", []
    if "iphone" in model_tokens:
        nums = [t for t in model_tokens if t.isdigit() and len(t) <= 2]
        base = "iPhone" + (" " + nums[0] if nums else "")
    else:
        alnum = sorted([t for t in model_tokens if re.fullmatch(r"[a-z]{1,2}\d{1,3}", t)],
                       key=lambda x: -len(x))
        if alnum:
            b = alnum[0]
            base = b[0].upper() + b[1:]
    for q in QUALIFIER_ORDER:
        if q in model_tokens:
            quals.append(q.capitalize())
    label = " ".join([base] + quals).strip()
    return label if label else " ".join(sorted(model_tokens)).upper()


def detect_brand(tokens: list[str], norm: str) -> str | None:
    table = {
        "samsung": ["samsung"], "اپل": ["apple", "iphone", "ipad", "macbook"],
        "شیائومی": ["xiaomi", "redmi", "poco"], "ایسوس": ["asus"], "لنوو": ["lenovo"],
        "سونی": ["sony"], "هواوی": ["huawei"], "نوکیا": ["nokia"],
        "موتورولا": ["motorola"], "الجی": ["lg"], "اچپی": ["hp"], "دل": ["dell"],
        "انکر": ["anker"],
    }
    for canon, aliases in table.items():
        for a in aliases:
            if a in tokens:
                return canon
    return None


def detect_model(tokens: list[str], atext: str) -> set[str]:
    """استخراج کد مدل: s24 ultra / iphone 15 pro max / note 13 pro ..."""
    model: set[str] = set()
    for t in tokens:
        if t in QUALIFIERS:
            model.add(t)
    # iphone 15
    m = re.search(r"\biphone\s*(\d{1,2})\b", atext)
    if m:
        model.update({"iphone", m.group(1)})
    # s24 / a54 / m3 ...
    for m in re.finditer(r"\b([a-z]{1,2})\s?(\d{1,3})\b", atext):
        code = m.group(1) + m.group(2)
        if code in {"ps4", "ps5"}:
            continue
        model.add(code)
    # note 13  /  ردمی نوت 13
    m = re.search(r"\bnote\s*(\d{1,2})\b", atext)
    if m:
        model.add("note" + m.group(1))
    # galaxy tab s9 ...
    return model


def split_model(model: set[str], atext: str) -> tuple[set[str], set[str]]:
    """
    مدل را به دو بخشِ کاملاً متفاوت تقسیم می‌کند:

      model_num  ← کدِ محصول:  s24 / a07 / note13 / iphone15
      variant    ← پسوندِ تیپ: ultra / fe / pro / max / plus / fold ...

    چرا این تفکیک حیاتی است؟ چون «s24» و «ultra» یک جنس نیستند: اولی
    مشخص می‌کند کدام محصول، دومی فقط کدام تیپ از همان محصول. وقتی هر دو
    در یک مجموعه بودند، «S26 Ultra» برای جستجوی «S24 Ultra» امتیازِ
    مثبت می‌گرفت (فقط چون واژه‌ی ultra مشترک بود) و بالای جدول می‌آمد.
    """
    num: set[str] = set()
    var: set[str] = set()
    iph = re.search(r"\biphone\s*(\d{1,2})\b", atext)
    if iph:
        num.add("iphone" + iph.group(1))
    for t in model:
        if t in QUALIFIERS:
            var.add(t)
            continue
        if iph and t == iph.group(1):
            continue                       # عددِ آیفون را جداگانه نگه نمی‌داریم
        if any(c.isdigit() for c in t) and re.fullmatch(r"(?:note|iphone)?[a-z]{0,2}\d{1,3}", t):
            num.add(t)
            continue
        var.add(t)                         # مثل خودِ واژه‌ی iphone
    return num, var


# خانواده‌هایی که کدِ مدل‌شان بی‌گمان «گوشی» است
_PHONE_CODE = re.compile(r"^(?:s|a|m|f|z|j)\d{1,3}$|^note\d{1,3}$|^iphone\d{1,2}$")


def infer_category(atext: str, tokens: list[str], model_num: set[str]) -> str | None:
    """
    اگر کاربر دسته را ننوشته (مثلاً فقط «سامسونگ اس 24 اولترا» گفته)،
    از روی کدِ مدل حدس می‌زنیم — تا تبلت/لپ‌تاپ به‌جای گوشی نیاید.
    """
    if "tab" in tokens or "ipad" in tokens or "تبلت" in atext or "ایپد" in atext:
        return "تبلت"
    if any(_PHONE_CODE.match(t) for t in model_num):
        return "گوشی"
    return None


def detect_capacity(atext: str) -> list[int]:
    """ظرفیت‌ها را به گیگابایت برمی‌گرداند: 1 ترابایت → 1024"""
    # حذف عددهای مربوط به رم
    cleaned = re.sub(r"\bram\s*(\d{1,4})\b", " ", atext)
    cleaned = re.sub(r"\b(\d{1,4})\s*(gb|mb|tb)?\s*ram\b", " ", cleaned)
    cleaned = re.sub(r"\b(\d{1,4})\s*(gb|mb|tb)?\s*رم\b", " ", cleaned)

    caps: list[int] = []
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(tb|gb|mb|ssd|hdd)", cleaned):
        v = float(num)
        caps.append(int(v * 1024 if unit == "tb" else v))
    caps = sorted(set(caps))
    if len(caps) > 1:                      # 16GBِ رم را با 512GBِ حافظه اشتباه نگیریم
        big = [c for c in caps if c >= 64]
        caps = big or caps
    if caps:
        return caps
    # اگر واحدی نوشته نشده: اعدادِ معروفِ ظرفیت
    bare = [int(n) for n in re.findall(r"\b(\d+)\b", cleaned)
            if int(n) in COMMON_CAPS and int(n) >= 8]
    return sorted(set(bare))


def detect_ram(norm: str) -> int | None:
    m = (re.search(r"\bram\s*(\d{1,4})\b", norm)
         or re.search(r"\b(\d{1,4})\s*(?:gb|mb)?\s*ram\b", norm)
         or re.search(r"\b(\d{1,4})\s*(?:gb|گیگابایت)?\s*رم\b", norm))
    return int(m.group(1)) if m else None


def detect_color(tokens: list[str]) -> str | None:
    for t in tokens:
        if t in COLORS:
            return COLORS[t]
    return None


def detect_category(atext: str, tokens: list[str]) -> str | None:
    for cat, keys in CATEGORIES.items():
        for k in keys:
            if " " in k:
                if k in atext:
                    return cat
            elif k in tokens:
                return cat
    return None


def detect_accessory(tokens: list[str]) -> set[str]:
    """فقط اگر کلمه‌ی جانبی در ۵ واژه‌ی اول عنوان باشد (وگرنه «همراه قاب رایگان» را هم می‌اندازد)"""
    head = set(tokens[:5])
    return head & ACCESSORY_WORDS


def content_tokens(tokens: list[str]) -> list[str]:
    """واژه‌هایی که واقعاً معنا دارند (برای محاسبه‌ی پوشش)"""
    out = []
    for t in tokens:
        if t in STOPWORDS or t in QUALIFIERS or t in COLORS:
            continue
        if len(t) <= 1 and not t.isdigit():
            continue
        out.append(t)
    return out


def parse(text: str) -> dict:
    """یک عنوان (یا عبارت جستجوی کاربر) را به اجزا تجزیه می‌کند"""
    norm = normalize(text)
    toks = tokenize(norm)
    atext = " ".join(toks)              # متنِ معادل‌سازی‌شده: «آیفون ۱۵» → «iphone 15»
    model = detect_model(toks, atext)
    model_num, variant = split_model(model, atext)
    return {
        "raw": text,
        "norm": norm,
        "atext": atext,
        "tokens": toks,
        "brand": detect_brand(toks, atext),
        "model": model,
        "model_num": model_num,
        "variant": variant,
        "model_label": prettify_model(model),
        "caps": detect_capacity(atext),
        "ram": detect_ram(atext),
        "color": detect_color(toks),
        "category": detect_category(atext, toks),
        "accessory": detect_accessory(toks),
        "content": content_tokens(toks),
    }


def norm_tokens_for_match(parsed: dict) -> list[str]:
    """توکن‌های کلیدی که باید در نتیجه پیدا شوند"""
    core = set(parsed["content"])
    core |= set(parsed["model"])
    for c in parsed["caps"]:
        core.add(str(c))
    if parsed["brand"]:
        core.add(parsed["brand"])
    return [t for t in core if t]
