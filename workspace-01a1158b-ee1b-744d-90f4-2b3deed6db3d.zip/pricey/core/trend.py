"""
📈 تحلیلِ روندِ قیمت
----------------------------------------
تاریخچه‌ای را که دیده‌بان جمع کرده می‌گیرد و از آن می‌سازد:
  · آمارِ بازه (کمترین / بیشترین / میانگین / میانه)
  · میانگینِ متحرک
  · درصدِ تغییر نسبت به اولِ بازه و نسبت به میانگین
  · یک «سیگنال» — که فقط مقایسه است، پیش‌بینی نیست

نکته‌ی مهم: این تحلیل فقط درباره‌ی چیزی حرف می‌زند که خودمان اندازه
گرفته‌ایم. آینده را پیش‌بینی نمی‌کند و ادعا نمی‌کند فردا چه می‌شود.
"""

from datetime import datetime, timedelta
import statistics


def _parse(t):
    """«2026-10-04 09:01» را به datetime تبدیل می‌کند."""
    try:
        return datetime.strptime((t or "").strip(), "%Y-%m-%d %H:%M")
    except Exception:
        return None


def moving_average(vals, k):
    """میانگینِ متحرکِ ساده روی k نقطه‌ی آخر (هر نقطه شاملِ خودش)."""
    if k < 2 or len(vals) < 2:
        return []
    out = []
    for i in range(len(vals)):
        lo = max(0, i - k + 1)
        out.append(round(sum(vals[lo:i + 1]) / (i - lo + 1)))
    return out


def _signal(n, last, lo, hi, avg, vol_pct, win):
    """
    سیگنال بر اساسِ جایِ قیمتِ فعلی در بازه‌ای که دیده‌ایم.
    flat   = بازه عملاً ثابت بوده — «کِی بخری» فرقی ندارد
    buy    = نزدیکِ کمترینِ این بازه
    good   = پایین‌تر از میانگین
    high   = بالاتر از میانگین
    normal = نزدیکِ میانگین
    thin   = داده کافی نیست
    """
    if n < 3:
        return {
            "code": "thin", "icon": "⏳", "color": "var(--muted)",
            "title": "تاریخچه هنوز کوتاه است",
            "detail": (f"فقط {n} بار این کالا را بررسی کرده‌ام. "
                       "برای اینکه بتوانم «ارزان است یا گران» را با اطمینان بگویم، "
                       "حداقل ۳ بار بررسی لازم است — کمی صبر کن."),
        }

    # اگر کلِ بازه عملاً ثابت بوده، «کمترینِ بازه» افتخاری ندارد — روی نویز
    # سیگنالِ خرید نمی‌دهیم.
    if vol_pct < 1.5:
        return {
            "code": "flat", "icon": "➖", "color": "var(--blue)",
            "title": "قیمت در این بازه تقریباً ثابت بوده",
            "detail": (f"کلِ نوسانِ این بازه فقط {vol_pct}٪ است "
                       f"({lo:,} تا {hi:,} تومان). وقتی بازار این‌قدر ثابت است، "
                       "اینکه امروز بخری یا فردا، فرقِ پولیِ مهمی ندارد."),
        }

    if last <= lo * 1.01:
        return {
            "code": "buy", "icon": "🔥", "color": "var(--green)",
            "title": f"کمترینِ {win}",
            "detail": (f"قیمتِ الان ({last:,} تومان) کمترین عددی است که در "
                       f"{win} اندازه گرفته‌ام. اگر قصدِ خرید داشتی، این بهترین "
                       f"نقطه‌ای است که در این بازه دیده‌ام."),
        }

    pct = (last - avg) / avg * 100 if avg else 0
    if pct <= -3:
        return {
            "code": "good", "icon": "✅", "color": "var(--green)",
            "title": f"{abs(round(pct))}٪ پایین‌تر از میانگینِ {win}",
            "detail": (f"میانگینِ این بازه {avg:,} تومان است و الان {last:,} تومان است. "
                       f"نسبت به میانگین ارزان‌تر است — وقتِ بدی برای خرید نیست."),
        }
    if pct >= 3:
        return {
            "code": "high", "icon": "⏳", "color": "var(--amber)",
            "title": f"{round(pct)}٪ بالاتر از میانگینِ {win}",
            "detail": (f"میانگینِ این بازه {avg:,} تومان است و الان {last:,} تومان است. "
                       f"بالاتر از میانگین است — اگر عجله نداری، صبر کردن احتمالاً "
                       f"به نفعِ توست (البته تضمینی نیست)."),
        }
    return {
        "code": "normal", "icon": "➖", "color": "var(--blue)",
        "title": f"نزدیکِ میانگینِ {win}",
        "detail": (f"قیمت ({last:,} تومان) در حدودِ میانگینِ این بازه ({avg:,} تومان) "
                   f"است — نه ارزانِ استثنایی است، نه گران."),
    }


def analyze(history, days=None):
    """
    history : لیستِ {"t": "YYYY-MM-DD HH:MM", "min": int, "median":…, "count":…}
    days    : ۷ / ۳۰ / None(=همه)
    """
    try:
        days = int(days) if days not in (None, "", "all", 0) else None
    except (TypeError, ValueError):
        days = None

    pts = []
    for h in history or []:
        dt = _parse(h.get("t"))
        m = h.get("min")
        if dt is None or not m:
            continue
        pts.append({"t": h["t"], "dt": dt, "min": int(m),
                    "median": h.get("median"), "count": h.get("count")})
    pts.sort(key=lambda p: p["dt"])

    total = len(pts)
    if days and pts:
        cut = pts[-1]["dt"] - timedelta(days=int(days))
        pts = [p for p in pts if p["dt"] >= cut]

    n = len(pts)
    if n < 2:
        return {"ok": False, "total": total, "n": n,
                "reason": "برای کشیدنِ نمودار حداقل دو بار بررسی لازم است — "
                          "کمی صبر کن تا دیده‌بان دوباره چک کند."}

    mins = [p["min"] for p in pts]
    lo, hi = min(mins), max(mins)
    first, last = mins[0], mins[-1]
    avg = round(sum(mins) / n)
    med = round(statistics.median(mins))
    lo_i, hi_i = mins.index(lo), mins.index(hi)

    k = max(2, min(7, max(2, n // 4)))
    ma = moving_average(mins, k)

    rng = (hi - lo) or 1
    pos = round((last - lo) / rng * 100)
    change_pct = round((last - first) / first * 100, 1) if first else 0
    vs_avg_pct = round((last - avg) / avg * 100, 1) if avg else 0
    vol_pct = round(rng / avg * 100, 1) if avg else 0

    win = {7: "۷ روزِ گذشته", 30: "۳۰ روزِ گذشته"}.get(days, "کلِ تاریخچه")
    sig = _signal(n, last, lo, hi, avg, vol_pct, win)

    caveat = ""
    if n < 5:
        caveat = (f"⚠️ فقط {n} نقطه در این بازه دارم. عددها درست‌اند، "
                  "ولی با این تعداد نقطه نمی‌شود روندِ مطمئنی گفت.")
    elif days and n < 3:
        caveat = "⚠️ در این بازه داده‌ی کمی دارم — بازه‌ی «همه» را ببین."
    if n < total:
        caveat += ("" if caveat else "") + \
            (f" · این بازه {n} نقطه از {total} نقطه‌ی کل است.")

    return {
        "ok": True, "n": n, "total": total, "days": days or "all",
        "points": [{"t": p["t"], "min": p["min"],
                    "ma": ma[i] if ma else None,
                    "is_lo": i == lo_i, "is_hi": i == hi_i} for i, p in enumerate(pts)],
        "stats": {"first": first, "last": last, "lo": lo, "hi": hi,
                  "avg": avg, "median": med,
                  "lo_t": pts[lo_i]["t"], "hi_t": pts[hi_i]["t"],
                  "first_t": pts[0]["t"], "last_t": pts[-1]["t"]},
        "change_pct": change_pct, "vs_avg_pct": vs_avg_pct,
        "vol_pct": vol_pct, "pos": pos, "ma_k": k,
        "signal": sig, "caveat": caveat.strip(" ·"),
    }
