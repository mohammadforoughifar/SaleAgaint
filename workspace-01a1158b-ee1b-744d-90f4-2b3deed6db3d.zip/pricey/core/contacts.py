"""
یافتنِ اطلاعات تماسِ فروشگاه‌ها با دنبال‌کردنِ لینک
---------------------------------------------------
لینکِ ریدایرکتِ ترب  →  آدرسِ واقعی  →  صفحه‌ی اصلی  →  «تماس با ما»  →  شماره تلفن
"""

import json
import os
import re
from urllib.parse import urljoin, urlparse

import requests

try:
    from bs4 import BeautifulSoup
    HAVE_SOUP = True
except ImportError:
    HAVE_SOUP = False

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_PATH = os.path.join(BASE, "data", "contacts.json")

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "fa-IR,fa;q=0.9,en;q=0.8",
}

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "0123456789" + "0123456789")

# الگوهای شماره تلفنِ ایران
RE_LANDLINE = re.compile(r"(?<!\d)0\d{2}\s?[-.]?\s?\d{7,8}(?!\d)")   # 021-47708000
RE_MOBILE = re.compile(r"(?<!\d)09\d{9}(?!\d)")                       # 09123456789
RE_TOLLFREE = re.compile(r"(?<!\d)(1536|9099\d{6}|096\d{2})(?!\d)")   # 1536 / 9099...

# کلماتِ کلیدیِ صفحه‌ی تماس
CONTACT_WORDS = ("تماس", "ارتباط", "contact", "about", "درباره", "پشتیبانی",
                 "support", "خدمات", "درباره-ما", "contactus", "contact-us")

# دامنه‌های نمونه/مستندات — این‌ها فروشگاه واقعی نیستند، وقت را تلف نکن
SKIP_HOSTS = {"example.com", "example.org", "example.net", "example.edu",
              "localhost", "127.0.0.1", "0.0.0.0", "test.com", "domain.com",
              "yoursite.com", "site.com", "shop.example.com"}
SKIP_SUFFIX = (".test", ".invalid", ".local", ".example", ".localhost")


def is_dummy_host(host: str) -> bool:
    h = (host or "").lower().split(":")[0]
    return (not h) or h in SKIP_HOSTS or h.endswith(SKIP_SUFFIX)


# ------------------------------------------------------------------ ابزارها
def to_ascii_digits(text: str) -> str:
    return (text or "").translate(_DIGITS)


def clean_phone(p: str) -> str:
    p = to_ascii_digits(p)
    p = re.sub(r"[^\d]", "", p)
    if len(p) == 11 and p.startswith("09"):
        return p                                   # موبایل: 09123456789
    if len(p) == 11 and p.startswith("0"):
        return f"{p[:3]}-{p[3:]}"                  # ثابت: 021-47708000
    if len(p) == 10 and p.startswith("9"):
        return "0" + p
    return p


def extract_phones(text: str, limit: int = 6) -> list[str]:
    """همه‌ی شماره‌های یک متن/صفحه را درمی‌آورد"""
    t = to_ascii_digits(text or "")
    found: list[str] = []
    for rx in (RE_LANDLINE, RE_MOBILE, RE_TOLLFREE):
        for m in rx.findall(t):
            p = clean_phone(m if isinstance(m, str) else "".join(m))
            if p and p not in found:
                found.append(p)
    # اولویت با تلفنِ ثابتِ فروشگاه، بعد موبایل
    def rank(p: str) -> int:
        if re.match(r"^0\d{2}-\d{7,8}$", p):
            return 0
        if p.startswith("09"):
            return 2
        return 1
    found.sort(key=lambda x: (rank(x), -len(x)))
    return found[:limit]


def _get(url: str, timeout: int = 10):
    return requests.get(url, headers=HEADERS, timeout=timeout,
                        allow_redirects=True)


def decode(resp) -> str:
    """
    خیلی از سایت‌های ایرانی charset اعلام نمی‌کنند و requests پیش‌فرض را
    latin-1 می‌گذارد → متنِ فارسی خراب می‌شود و شماره‌ها پیدا نمی‌شوند.
    این تابع encoding را از تگِ meta یا از خودِ محتوا حدس می‌زند.
    """
    enc = None
    try:
        m = re.search(rb'charset=["\']?\s*([A-Za-z0-9_\-]+)',
                      resp.content[:4096], re.I)
        if m:
            enc = m.group(1).decode("ascii", "ignore")
    except Exception:
        pass
    if not enc:
        enc = resp.encoding or ""
    if enc.lower() in ("", "iso-8859-1", "latin-1", "ascii", "windows-1252"):
        try:
            enc = resp.apparent_encoding or "utf-8"
        except Exception:
            enc = "utf-8"
    try:
        return resp.content.decode(enc, errors="replace")
    except (LookupError, TypeError):
        return resp.content.decode("utf-8", errors="replace")


def resolve(url: str, timeout: int = 10) -> tuple[str, str, str]:
    """لینکِ ریدایرکت را باز می‌کند و به (آدرسِ نهایی، متنِ صفحه، دامنه) می‌رسد"""
    if not url or not url.startswith("http"):
        return "", "", ""
    try:
        r = _get(url, timeout)
        if r.status_code >= 400:
            return r.url, "", ""
        ctype = r.headers.get("content-type", "")
        text = decode(r) if ("html" in ctype or "text" in ctype) else ""
        return r.url, text, urlparse(r.url).netloc
    except Exception:
        return url, "", urlparse(url).netloc


def contact_links(base_url: str, html: str, limit: int = 3) -> list[str]:
    """لینک‌های مربوط به صفحه‌ی تماس را پیدا می‌کند"""
    if not html:
        return []
    links: list[str] = []
    if HAVE_SOUP:
        try:
            soup = BeautifulSoup(html, "html.parser")
            for a in soup.find_all("a", href=True):
                href = a["href"]
                label = (a.get_text(" ", strip=True) or "") + " " + href
                low = label.lower()
                if any(w in low for w in CONTACT_WORDS):
                    full = urljoin(base_url, href)
                    if full.startswith("http") and full not in links:
                        links.append(full)
        except Exception:
            pass
    if not links:                                    # بدونِ bs4 یا شکستِ پارس
        for m in re.finditer(r'href=["\']([^"\']+)["\']', html):
            href = m.group(1)
            if any(w in href.lower() for w in CONTACT_WORDS):
                full = urljoin(base_url, href)
                if full.startswith("http") and full not in links:
                    links.append(full)
    return links[:limit]


# ------------------------------------------------------------------ جستجوگر
def norm(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"[\s\-_()«»\.,،:/\\]+", "", s)
    s = s.replace("ك", "ک").replace("ي", "ی").replace("ة", "ه")
    return s.replace("آ", "ا").replace("أ", "ا").replace("إ", "ا")


def phone_table() -> dict:
    """جدولِ نامِ فروشگاه → شماره تلفن (از shops.json + کشِ خزش)"""
    table: dict[str, str] = {}
    try:
        with open(os.path.join(BASE, "data", "shops.json"), encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    for s in data.get("shops", []) + data.get("data_sources", []):
        if s.get("name") and s.get("phone") not in (None, "", "—"):
            table[norm(s["name"])] = s["phone"]
    for site, info in (load_cache() or {}).items():
        ph = (info or {}).get("phones") or []
        nm = (info or {}).get("name")
        if nm and ph:
            table.setdefault(norm(nm), " / ".join(ph[:2]))
    return table


def find_phone(seller: str, table: dict | None = None) -> str:
    table = table if table is not None else phone_table()
    n = norm(seller)
    if not n:
        return "—"
    if n in table:
        return table[n]
    for k, v in table.items():
        if len(k) >= 4 and (k in n or (len(n) >= 4 and n in k)):
            return v
    return "—"


def load_cache() -> dict:
    try:
        with open(CACHE_PATH, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_cache(cache: dict):
    try:
        os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
        with open(CACHE_PATH, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, ensure_ascii=False, indent=1)
    except Exception:
        pass


def lookup(url: str, timeout: int = 10, use_cache: bool = True,
           cache: dict | None = None) -> dict:
    """برای یک لینک: آدرسِ واقعی + شماره تلفن‌ها را پیدا می‌کند"""
    cache = cache if cache is not None else (load_cache() if use_cache else {})
    out = {"url": url or "", "final_url": "", "site": "", "phones": [],
           "source": "", "reached": False}

    if not url or not url.startswith("http"):
        return out

    host0 = urlparse(url).netloc
    if is_dummy_host(host0):
        out["source"] = "دامنه‌ی نمونه — رد شد"
        out["site"] = host0
        return out

    # ۱) باز کردنِ ریدایرکت
    final_url, html, netloc = resolve(url, timeout)
    out["final_url"], out["site"] = final_url, netloc

    if netloc and use_cache and netloc in cache:
        cached = cache[netloc]
        out["phones"] = cached.get("phones", [])
        out["source"] = "کش"
        return out

    out["reached"] = bool(html)

    # ۲) شماره را در همان صفحه بگرد
    phones = extract_phones(html)
    src = "صفحه‌ی محصول"

    # ۳) اگر نبود: صفحه‌ی اصلی + صفحه‌ی تماس
    if not phones and netloc:
        try:
            root = f"{urlparse(final_url).scheme}://{netloc}"
            _, root_html, _ = resolve(root, timeout)
            phones = extract_phones(root_html)
            src = "صفحه‌ی اصلی"
            if not phones and root_html:
                for cl in contact_links(root, root_html, limit=3):
                    _, ch, _ = resolve(cl, timeout)
                    phones = extract_phones(ch)
                    if phones:
                        out["final_url"] = cl
                        src = "صفحه‌ی تماس"
                        break
        except Exception:
            pass

    out["phones"], out["source"] = phones, (src if phones else "")
    if netloc and use_cache:
        cache[netloc] = {"phones": phones, "site": netloc, "url": final_url}
    return out
