# اگر run_windows.bat کار نکرد، این فایل را با راست‌کلیک → Run with PowerShell اجرا کن
$ErrorActionPreference = "Continue"
$host.UI.RawUI.WindowTitle = "Price Finder"
Set-Location -Path $PSScriptRoot
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host "   Price Finder - Torob & Digikala" -ForegroundColor Cyan
Write-Host "  ==========================================" -ForegroundColor Cyan
Write-Host ""

$py = $null
foreach ($c in @("py -3", "python", "python3")) {
    $exe = ($c -split " ")[0]
    if (Get-Command $exe -ErrorAction SilentlyContinue) {
        $p = (Get-Command $exe).Source
        if ($p -notlike "*WindowsApps*") { $py = $c; break }
    }
}

if (-not $py) {
    Write-Host "  [ERROR] Python is not installed." -ForegroundColor Red
    Write-Host ""
    Write-Host "  1. Go to https://www.python.org/downloads/"
    Write-Host "  2. Install Python 3.12 and CHECK 'Add Python to PATH'"
    Write-Host "  3. Run this file again"
    Write-Host ""
    Read-Host "  Press Enter to close"
    exit 1
}

Write-Host "  Found: $py" -ForegroundColor Green
Write-Host "  Starting..." -ForegroundColor Green
Write-Host ""
Invoke-Expression "$py -u run.py"

Write-Host ""
Read-Host "  Press Enter to close"
