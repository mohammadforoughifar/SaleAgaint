#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
echo
if command -v python3 >/dev/null 2>&1; then
    python3 run.py
else
    echo "  پایتون پیدا نشد!"
    echo "  مک:     brew install python3"
    echo "  لینوکس: sudo apt install python3 python3-pip"
    echo
    read -r -p "  Enter را بزنید..." _
fi
